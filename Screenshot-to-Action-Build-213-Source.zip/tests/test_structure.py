"""Static native-format checks, including field classes missed in earlier builds."""
import json,pathlib,plistlib,re,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
PATH=ROOT/'dist/Screenshot-to-Action-v2.0-Build-213.shortcut'
CAT=json.loads((ROOT/'tests/validation_catalog.json').read_text())
P=plistlib.loads(PATH.read_bytes());A=P['WFWorkflowActions']

def walk(obj):
    if isinstance(obj,dict):
        yield obj
        for value in obj.values():yield from walk(value)
    elif isinstance(obj,list):
        for value in obj:yield from walk(value)

class Structure(unittest.TestCase):
    def test_binary_xml_roundtrip(self):
        self.assertTrue(PATH.read_bytes().startswith(b'bplist00'))
        self.assertEqual(P,plistlib.loads((ROOT/'dist/Screenshot-to-Action-v2.0-Build-213.xml').read_bytes()))
    def test_unique_uuids_and_backward_magic_variables(self):
        seen=set()
        for a in A:
            p=a['WFWorkflowActionParameters']
            for ref in walk(p):
                if ref.get('Type')=='ActionOutput':self.assertIn(ref['OutputUUID'],seen)
            self.assertNotIn(p['UUID'],seen);seen.add(p['UUID'])
    def test_control_flow_balanced(self):
        stack=[]
        for a in A:
            p=a['WFWorkflowActionParameters'];mode=p.get('WFControlFlowMode')
            if mode is None:continue
            if mode==0:stack.append([a['WFWorkflowActionIdentifier'],p['GroupingIdentifier'],p.get('WFMenuItems'),[]])
            else:
                self.assertTrue(stack);self.assertEqual(stack[-1][0],a['WFWorkflowActionIdentifier']);self.assertEqual(stack[-1][1],p['GroupingIdentifier'])
                if mode==1 and stack[-1][2] is not None:stack[-1][3].append(p['WFMenuItemTitle'])
                if mode==2:
                    _,_,labels,actual=stack.pop()
                    if labels is not None:self.assertEqual(labels,actual)
        self.assertFalse(stack)
    def test_home_menu_items_and_quit_last(self):
        home=next(a['WFWorkflowActionParameters'] for a in A if a['WFWorkflowActionIdentifier'].endswith('.choosefrommenu'))
        self.assertEqual(home['WFMenuItems'],['🖼 Choose Photo','📷 Take a Photo','📚 All Captures','💾 Backup and Restore','ℹ️ About and Help','⏹ Quit'])
    def test_restore_has_no_string_comparison_chips(self):
        start=next(i for i,a in enumerate(A) if a['WFWorkflowActionParameters'].get('WFMenuItemTitle')=='♻️ Restore Backup')
        end=next(i for i in range(start+1,len(A)) if A[i]['WFWorkflowActionParameters'].get('WFMenuItemTitle')=='🏠 Main Menu')
        restore=A[start:end]
        checks=[a['WFWorkflowActionParameters']['WFCondition'] for a in restore
                if a['WFWorkflowActionIdentifier'].endswith('.conditional') and a['WFWorkflowActionParameters'].get('WFControlFlowMode')==0]
        self.assertTrue(checks);self.assertTrue(all(x in (100,101) for x in checks))
        self.assertTrue(any(a['WFWorkflowActionIdentifier'].endswith('.text.match') for a in restore))
    def test_notes_action_matches_iphone_export(self):
        notes=[a for a in A if a['WFWorkflowActionIdentifier']=='com.apple.mobilenotes.SharingExtension']
        self.assertEqual(len(notes),1)
        p=notes[0]['WFWorkflowActionParameters']
        self.assertEqual(p['AppIntentDescriptor'],{'AppIntentIdentifier':'CreateNoteLinkAction','BundleIdentifier':'com.apple.mobilenotes','Name':'Notes','TeamIdentifier':'0000000000'})
        refs=p['WFCreateNoteInput']['Value']['attachmentsByRange'].values()
        self.assertEqual({r['VariableName'] for r in refs},{'Title','Summary','Body','CaptureImage'})
    def test_old_warning_and_tag_ui_removed(self):
        raw=json.dumps(P,ensure_ascii=False)
        for old in ['Earlier action needs review','Review the earlier attempt','Activity & Recovery','Category & Tags','Mark Done','Archive Capture','WFValueVariable']:
            self.assertNotIn(old,raw)
        for a in A:
            if a['WFWorkflowActionIdentifier']=='is.workflow.actions.dictionary':
                keys=[f['WFKey'] for f in a['WFWorkflowActionParameters']['WFItems']['Value']['WFDictionaryFieldValueItems']]
                self.assertNotIn('tags',keys);self.assertNotIn('pending',keys)
    def test_text_fields_have_text_serialization(self):
        # These field classes come from Apple's extracted Toolkit metadata,
        # corroborated by native source exports for Set Dictionary Value.
        for a in A:
            p=a['WFWorkflowActionParameters']
            for field in CAT['tools'].get(a['WFWorkflowActionIdentifier'],{}).get('parameters',[]):
                value=p.get(field['key'])
                if field['typePythonName'] in ('str','DateTime','URL') and isinstance(value,dict):
                    self.assertEqual(value.get('WFSerializationType'),'WFTextTokenString',(a['WFWorkflowActionIdentifier'],field['key']))
    def test_dictionary_update_value_references_assigned_source(self):
        found=0
        for a in A:
            if not a['WFWorkflowActionIdentifier'].endswith('.setvalueforkey'):continue
            found+=1;p=a['WFWorkflowActionParameters'];value=p['WFDictionaryValue']
            self.assertEqual(value['WFSerializationType'],'WFTextTokenString')
            self.assertEqual(value['Value']['string'],'\ufffc');self.assertTrue(value['Value']['attachmentsByRange'])
            self.assertEqual(p['WFDictionary']['WFSerializationType'],'WFTextTokenAttachment')
        self.assertEqual(found,4)
    def test_token_offsets_valid_utf16(self):
        for a in A:
            for d in walk(a['WFWorkflowActionParameters']):
                if d.get('WFSerializationType')!='WFTextTokenString':continue
                value=d['Value'];raw=value['string'].encode('utf-16-le');positions=set()
                for key,ref in value.get('attachmentsByRange',{}).items():
                    start,length=map(int,re.findall(r'\d+',key));self.assertEqual(length,1)
                    self.assertEqual(raw[start*2:(start+1)*2],b'\xfc\xff');positions.add(start)
                    self.assertIn(ref.get('Type'),('ActionOutput','Variable','ExtensionInput','Ask'))
                self.assertEqual(positions,{i//2 for i in range(0,len(raw),2) if raw[i:i+2]==b'\xfc\xff'})
    def test_parameter_keys_and_ids(self):
        exceptions={'documentpicker.open':{'WFShowFilePicker'},'count':{'WFInput'},
                    'ask':{'WFAskActionDateGranularity'},'adjustdate':{'WFInput','WFAdjustOffsetPicker'},
                    'addnewevent':{'WFCalendarItemCalendar','WFCalendarItemDates'}}
        for a in A:
            ident=a['WFWorkflowActionIdentifier'];short=ident.removeprefix('is.workflow.actions.');p=a['WFWorkflowActionParameters']
            if ident=='com.apple.mobilenotes.SharingExtension':
                self.assertEqual(set(p),{'AppIntentDescriptor','WFCreateNoteInput','UUID'});continue
            if ident=='com.apple.Notes.CreateNoteIntent':
                self.assertEqual(set(p)-{'name','content','attachments','isPinned','OpenWhenRun','UUID'},set())
                continue
            if ident=='is.workflow.actions.createnote':
                self.assertEqual(set(p)-{'WFCreateNoteTitle','WFCreateNoteBody','WFInput','ShowWhenRun','UUID'},set())
                continue
            if short in ('conditional','choosefrommenu','repeat.count','repeat.each'):continue
            self.assertIn(ident,CAT['tools'])
            allowed={f['key'] for f in CAT['tools'][ident]['parameters']}|{'UUID','CustomOutputName'}|exceptions.get(short,set())
            self.assertFalse(set(p)-allowed,(short,set(p)-allowed))
    def test_enum_values_and_ios_ids(self):
        ids=set(CAT['ios_ids']['ids'])
        for a in A:
            ident=a['WFWorkflowActionIdentifier'];p=a['WFWorkflowActionParameters']
            if ident not in ('com.apple.mobilenotes.SharingExtension','com.apple.Notes.CreateNoteIntent','is.workflow.actions.createnote') and ident.removeprefix('is.workflow.actions.') not in ('conditional','choosefrommenu','repeat.count','repeat.each','extracttextfromimage'):self.assertIn(ident,ids)
            for field in CAT['tools'].get(ident,{}).get('parameters',[]):
                value=p.get(field['key']);enum=CAT['enums'].get(field.get('typePythonName'))
                if enum and isinstance(value,str):self.assertIn(value,{case['id'] for case in enum['cases']})
    def test_all_required_inputs_explicit(self):
        required={'getvalueforkey':['WFInput'],'setvalueforkey':['WFDictionaryKey','WFDictionaryValue','WFDictionary'],
            'setvariable':['WFInput'],'appendvariable':['WFInput'],'setitemname':['WFInput','WFName'],
            'documentpicker.open':['WFFile','WFGetFilePath'],'documentpicker.save':['WFInput','WFFolder','WFFileDestinationPath'],
            'image.convert':['WFInput'],'base64encode':['WFInput'],'extracttextfromimage':['imageFile'],
            'text.match':['text'],'text.changecase':['text'],'text.trimwhitespace':['WFInput'],'text.replace':['WFInput'],
            'choosefromlist':['WFInput'],'count':['Input','WFInput'],'hash':['WFInput'],'detect.dictionary':['WFInput'],
            'detect.images':['WFInput'],'detect.text':['WFInput'],'makezip':['WFInput'],'unzip':['WFArchive'],
            'file.delete':['WFInput'],'share':['WFInput'],'openurl':['WFInput'],'file.getfoldercontents':['WFFolder'],
            'adjustdate':['WFDate','WFInput','WFDuration'],'format.date':['WFDate'],'detect.link':['WFInput'],
            'setclipboard':['WFInput'],'makepdf':['WFInput'],'previewdocument':['WFInput'],'urlencode':['WFInput'],
            'askllm':['WFLLMPrompt','WFLLMModel','WFGenerativeResultType','FollowUp']}
        for a in A:
            short=a['WFWorkflowActionIdentifier'].removeprefix('is.workflow.actions.');p=a['WFWorkflowActionParameters']
            for key in required.get(short,[]):self.assertIn(key,p);self.assertIsNotNone(p[key]);self.assertNotEqual(p[key],'')
    def test_calendar_one_datetime_ask_and_calendar_picker(self):
        in_event=False;asks=[];event=None
        for a in A:
            p=a['WFWorkflowActionParameters']
            if p.get('WFMenuItemTitle')=='📅 Create Calendar Event':in_event=True
            elif in_event and p.get('WFMenuItemTitle'):in_event=False
            if in_event and a['WFWorkflowActionIdentifier'].endswith('.ask'):asks.append(p)
            if in_event and a['WFWorkflowActionIdentifier'].endswith('.addnewevent'):event=p
        self.assertEqual(len(asks),1);self.assertEqual(asks[0]['WFInputType'],'Date')
        self.assertEqual(asks[0]['WFAskActionDateGranularity'],'Date and Time')
        self.assertTrue(event['ShowWhenRun']);self.assertFalse(event['WFCalendarItemAllDay'])
        self.assertEqual(event['WFCalendarDescriptor']['Value']['Type'],'Ask')
        self.assertEqual(event['WFCalendarItemCalendar']['Value']['Type'],'Ask')

    def test_cloud_model_receives_photo_and_returns_dictionary(self):
        uses=[a for a in A if a['WFWorkflowActionIdentifier'].endswith('.askllm')]
        self.assertEqual(len(uses),1)
        p=uses[0]['WFWorkflowActionParameters']
        self.assertEqual(p['WFLLMModel'],'com.apple.Shortcuts.AskMontaraAction')
        self.assertEqual(p['WFGenerativeResultType'],'Dictionary')
        self.assertFalse(p['FollowUp'])
        encoded=p['WFLLMPrompt'];self.assertEqual(encoded['WFSerializationType'],'WFTextTokenString')
        refs=encoded['Value']['attachmentsByRange'].values()
        self.assertTrue(any(ref.get('Type')=='Variable' and ref.get('VariableName')=='PNG' for ref in refs))
        self.assertFalse(any(a['WFWorkflowActionIdentifier'].endswith('.extracttextfromimage') for a in A))
    def test_iso_dates_without_custom_format_ambiguity(self):
        for a in A:
            if not a['WFWorkflowActionIdentifier'].endswith('.format.date'):continue
            p=a['WFWorkflowActionParameters']
            if p['WFDateFormatStyle']=='Custom':self.assertIn(p['WFDateFormat'],('yyyy-MM-dd','yyyyMMdd-HHmmss-SSS'));continue
            self.assertEqual(p['WFDateFormatStyle'],'ISO 8601');self.assertTrue(p['WFISO8601IncludeTime'])
            self.assertNotIn('WFDateFormatString',p)
    def test_output_actions_do_not_write_archive(self):
        manifest=json.loads((ROOT/'dist/build-manifest.json').read_text());start=manifest['sections']['actions'];stop=manifest['sections']['backups']
        self.assertFalse(any(a['WFWorkflowActionIdentifier'].endswith(('.documentpicker.save','.setvalueforkey')) for a in A[start:stop]))
        self.assertLess(len(A),675)
    def test_delete_confirmed_on_same_branch(self):
        stack=[];confirm=[];count=0
        for a in A:
            p=a['WFWorkflowActionParameters'];mode=p.get('WFControlFlowMode')
            if mode==0:stack.append((p['GroupingIdentifier'],0))
            elif mode==1:
                group,branch=stack.pop();stack.append((group,branch+1))
            elif mode==2:stack.pop()
            if a['WFWorkflowActionIdentifier'].endswith('.alert') and p.get('WFAlertActionCancelButtonShown') and 'delete' in p['WFAlertActionTitle'].lower():confirm.append(tuple(stack))
            if a['WFWorkflowActionIdentifier'].endswith('.file.delete'):
                count+=1;self.assertTrue(p['WFDeleteImmediatelyDelete'])
                self.assertTrue(any(tuple(stack)[:len(c)]==c for c in confirm))
        self.assertEqual(count,1)
    def test_no_personal_bookmarks_or_runtime_scripts(self):
        for a in A:
            ident=a['WFWorkflowActionIdentifier'];self.assertFalse(ident.endswith(('.runworkflow','.downloadurl','.runjavascriptonwebpage','.runapplescript','.runshellscript')))
            for d in walk(a['WFWorkflowActionParameters']):self.assertNotIn('crossDeviceItemID',d);self.assertNotIn('bookmarkData',d)
    def test_loop_item_binding_depth(self):
        depth=0
        for a in A:
            p=a['WFWorkflowActionParameters']
            if a['WFWorkflowActionIdentifier'].endswith(('.repeat.each','.repeat.count')):
                if p['WFControlFlowMode']==0:depth+=1
                elif p['WFControlFlowMode']==2:depth-=1
            for d in walk(p):
                if d.get('Type')=='Variable' and d.get('VariableName','').startswith('Repeat Item'):
                    self.assertEqual(d['VariableName'],'Repeat Item'+(' '+str(depth) if depth>1 else ''))
    def test_credit_and_share_extension(self):
        raw=json.dumps(P,ensure_ascii=False);self.assertIn('SurfKraken',raw);self.assertIn('https://github.com/surfkraken',raw)
        self.assertIn('pending owner approval',raw);self.assertEqual(P['WFWorkflowInputContentItemClasses'],['WFImageContentItem'])

if __name__=='__main__':unittest.main(verbosity=2)
