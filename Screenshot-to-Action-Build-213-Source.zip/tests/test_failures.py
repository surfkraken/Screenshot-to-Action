import copy,json,random,string,tempfile,plistlib,sys,pathlib,unittest
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from native_model import Engine,FS,File,image,Cancelled
from test_workflows import SHORTCUT,MAIN,run,add,record,resume,restore_file,exported,zip_records,legacy

class Failures(unittest.TestCase):
    def test_cancel_camera(self):
        e=run(menus=['📷 Take a Photo'],cancel_native='takephoto');self.assertFalse(e.fs.capture_records())
    def test_cancel_photos_empty_selection(self):
        e=run(menus=['🖼 Choose Photo'],photos=[[]]);self.assertFalse(e.fs.capture_records());self.assertTrue(e.alerts)
    def test_nonimage_input(self):
        e=run(incoming=File('bad.png',b'not an image'));self.assertFalse(e.fs.capture_records())
    def test_cancel_shared_image_choice(self):
        e=run(incoming=[image('one'),image('two')],choices=[Cancelled]);self.assertFalse(e.fs.capture_records())
    def test_cloud_analysis_failure_preserves_original_and_existing_archive(self):
        e=add();before=dict(e.fs.files);source=image('new image')
        e=run(e.fs,incoming=source,fail_action='askllm')
        self.assertEqual(e.outcome,'injected-failure');self.assertEqual(e.fs.files,before);self.assertEqual(e.incoming.data,source.data)
    def test_cancel_rename(self):
        e=add();before=dict(e.fs.files);e=resume(e.fs,['✏️ Rename Capture'],asks=[Cancelled]);self.assertEqual(e.fs.files,before)
    def test_blank_title_keeps_original(self):
        e=add();before=dict(e.fs.files);e=resume(e.fs,['✏️ Rename Capture'],asks=['   ']);self.assertEqual(e.fs.files,before)
    def test_blank_text_keeps_original(self):
        e=add();before=dict(e.fs.files);e=resume(e.fs,['📝 Edit Text'],asks=['']);self.assertEqual(e.fs.files,before)
    def test_delete_cancel_preserves_everything(self):
        e=add();before=dict(e.fs.files);e=resume(e.fs,['🗑 Delete Capture'],cancel_alert='🗑 Delete this capture?')
        self.assertEqual(e.fs.files,before);self.assertFalse(e.fs.deletes)
    def test_native_delete_cancel_preserves_everything(self):
        e=add();before=dict(e.fs.files);e=resume(e.fs,['🗑 Delete Capture'],cancel_native='file.delete')
        self.assertEqual(e.fs.files,before)
    def test_native_calendar_cancel_has_no_checkpoint(self):
        e=add();before=dict(e.fs.files)
        e=resume(e.fs,['⚡ Take Action','📅 Create Calendar Event'],asks=['2026-11-15T14:30:00-07:00'],cancel_native='addnewevent')
        self.assertEqual(e.fs.files,before);self.assertFalse(e.alerts);self.assertFalse(any(a=='addnewevent' for a,_ in e.effects))
        e=resume(e.fs,['📄 View Text']);self.assertFalse(e.alerts)
    def test_date_picker_cancel(self):
        e=add();before=dict(e.fs.files);e=resume(e.fs,['⚡ Take Action','📅 Create Calendar Event'],asks=[Cancelled])
        self.assertEqual(e.fs.files,before);self.assertFalse(any(a=='addnewevent' for a,_ in e.effects))
    def test_failed_reminder_does_not_change_capture(self):
        e=add();before=dict(e.fs.files);e=resume(e.fs,['⚡ Take Action','🔔 Create Reminder','📥 No Due Date'],asks=['Call'],fail_action='addnewreminder')
        self.assertEqual(e.fs.files,before);self.assertFalse(e.alerts)
    def test_partial_checklist_no_archive_rewrites(self):
        e=add();before=dict(e.fs.files);e=resume(e.fs,['⚡ Take Action','☑️ Create Checklist'],asks=['Milk\nBread'],choices=['first','all'],fail_action='addnewreminder',fail_occurrence=2)
        self.assertEqual([p['WFCalendarItemTitle'] for a,p in e.effects if a=='addnewreminder'],['Milk']);self.assertEqual(e.fs.files,before)
    def test_empty_checklist_creates_nothing(self):
        e=add();e=resume(e.fs,['⚡ Take Action','☑️ Create Checklist'],asks=['  \n\n']);self.assertFalse(any(a=='addnewreminder' for a,_ in e.effects))
    def test_checklist_limit(self):
        e=add();e=resume(e.fs,['⚡ Take Action','☑️ Create Checklist'],asks=['\n'.join('Task '+str(i) for i in range(51))],choices=['first','all'])
        self.assertFalse(any(a=='addnewreminder' for a,_ in e.effects))
    def test_blank_copy(self):
        e=add();e=resume(e.fs,['⚡ Take Action','📋 Copy Text'],asks=['']);self.assertFalse(any(a=='clipboard' for a,_ in e.effects))
    def test_missing_url(self):
        e=add(ocr='No link');e=resume(e.fs,['⚡ Take Action','🔗 Open a Web Link']);self.assertFalse(any(a=='openurl' for a,_ in e.effects))
    def test_nonweb_url_is_blocked(self):
        e=add(ocr='tel:5550100');e=resume(e.fs,['⚡ Take Action','🔗 Open a Web Link']);self.assertFalse(any(a=='openurl' for a,_ in e.effects))
    def test_contact_cancel(self):
        ai={'title':'Card','text':'Jamie Doe','summary':'Contact card.','address':'','contactFirstName':'Jamie',
            'contactLastName':'Doe','contactCompany':'','contactPhone':'','contactEmail':'','contactNotes':''}
        e=add(model_result=ai);before=dict(e.fs.files);e=resume(e.fs,['⚡ Take Action','👤 Create Contact'],cancel_native='addnewcontact');self.assertEqual(e.fs.files,before)
    def test_bad_schema(self):
        r=record(add().fs);r['schema']='99';e=restore_file(exported(r));self.assertFalse(e.fs.capture_records())
    def test_bad_format(self):
        r=record(add().fs);r['format']='other';e=restore_file(exported(r));self.assertFalse(e.fs.capture_records())
    def test_path_traversal(self):
        r=record(add().fs);r['id']='../../data';e=restore_file(exported(r));self.assertFalse(e.fs.capture_records())
    def test_hash_mismatch(self):
        r=record(add().fs);r['id']='0'*64;e=restore_file(exported(r));self.assertFalse(e.fs.capture_records())
    def test_missing_text_key(self):
        r=record(add().fs);del r['text'];e=restore_file(exported(r));self.assertFalse(e.fs.capture_records())
    def test_bad_json_before_any_import(self):
        r=record(add().fs)
        with self.assertRaises(json.JSONDecodeError):
            e=Engine(SHORTCUT,menus=['💾 Backup and Restore','♻️ Restore Backup'],selected_files=[zip_records([r,b'broken json'])]);e.run()
        self.assertFalse(e.fs.capture_records())
    def test_later_corrupt_record_prevents_entire_import(self):
        r=record(add().fs);bad={**r,'id':'0'*64};e=restore_file(zip_records([r,bad]));self.assertFalse(e.fs.capture_records())
    def test_unknown_extension(self):
        e=restore_file(File('backup.txt',b'text'));self.assertFalse(e.fs.capture_records())
    def test_empty_zip(self):
        e=restore_file(zip_records([]));self.assertFalse(e.fs.capture_records())
    def test_legacy_tags_and_pending_not_required_for_restore(self):
        r=record(add().fs);r['schema']='1';e=restore_file(exported(r));self.assertEqual(record(e.fs),r)
    def test_bad_dictionary_value_encoding_is_detected(self):
        p=plistlib.loads(SHORTCUT.read_bytes())
        for a in p['WFWorkflowActions']:
            q=a['WFWorkflowActionParameters']
            if a['WFWorkflowActionIdentifier'].endswith('.setvalueforkey'):
                value=q['WFDictionaryValue']['Value'];ref=next(iter(value['attachmentsByRange'].values()))
                q['WFDictionaryValue']={'WFSerializationType':'WFTextTokenAttachment','Value':ref}
        with tempfile.NamedTemporaryFile(suffix='.shortcut') as f:
            f.write(plistlib.dumps(p));f.flush()
            seed=add();e=Engine(f.name,fs=seed.fs,menus=['📚 All Captures','✏️ Rename Capture'],asks=['Changed'])
            with self.assertRaisesRegex(AssertionError,'Wrong native Value serialization'):e.run()
    def test_unicode_json_backup_roundtrips_50(self):
        rng=random.Random(200);alphabet='aB09"\\\n\t🐙📸é中{}[]$`'
        for i in range(50):
            title='Title '+''.join(rng.choice(alphabet) for _ in range(40));body='Body '+''.join(rng.choice(alphabet) for _ in range(250))
            e=add(ocr=body);e=resume(e.fs,['✏️ Rename Capture'],asks=[title]);saved=record(e.fs)
            restored=restore_file(zip_records([saved]));self.assertEqual(record(restored.fs),saved)

if __name__=='__main__':unittest.main(verbosity=2)
