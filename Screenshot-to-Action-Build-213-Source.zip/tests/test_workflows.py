import base64,datetime as dt,hashlib,io,json,pathlib,sys,unittest,zipfile
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from native_model import Engine,FS,File,image,Cancelled

SHORTCUT=pathlib.Path(__file__).resolve().parents[1]/'dist/Screenshot-to-Action-v2.0-Build-213.shortcut'
MAIN='🏠 Main Menu'

def run(fs=None,**kwargs):return Engine(SHORTCUT,fs=fs,**kwargs).run()
def add(fs=None,**kwargs):return run(fs,incoming=image(),**kwargs)
def record(fs):return next(iter(fs.capture_records().values()))
def resume(fs,menus=None,**kwargs):return run(fs,menus=['📚 All Captures']+list(menus or []),**kwargs)
def exported(r):return File('capture.json',json.dumps(r,ensure_ascii=False).encode())
def zip_records(records):
    out=io.BytesIO()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        for i,r in enumerate(records):z.writestr(str(i)+'.json',json.dumps(r,ensure_ascii=False) if not isinstance(r,bytes) else r)
    return File('backup.zip',out.getvalue())
def restore_file(f,fs=None,**kwargs):return run(fs,menus=['💾 Backup and Restore','♻️ Restore Backup'],selected_files=[f],**kwargs)
def legacy(r):
    r=dict(r);r.update(schema='1',status='acted',category='Work',tags='old tags',activity='Old log',pending='Earlier action',lastAction='Reminder');return r

class Workflows(unittest.TestCase):
    def test_capture_contents_and_one_write(self):
        e=add(ocr='Appointment\nBring tickets');r=record(e.fs)
        self.assertEqual(r['title'],'Appointment');self.assertEqual(r['text'],'Appointment\nBring tickets');self.assertEqual(r['schema'],'3')
        self.assertEqual(hashlib.sha256(r['image'].encode()).hexdigest(),r['id'])
        self.assertTrue(all(isinstance(x,str) for x in r.values()));self.assertEqual(len(e.fs.writes),1)
        self.assertNotIn('tags',r);self.assertNotIn('pending',r);self.assertNotIn('activity',r)
        self.assertLess(sum(e.action_counts.values()),140)
    def test_photo_picker(self):
        e=run(menus=['🖼 Choose Photo'],photos=[[image()]])
        self.assertEqual(len(e.fs.capture_records()),1)
    def test_camera(self):
        e=run(menus=['📷 Take a Photo'],photos=[[image('camera')]])
        self.assertEqual(len(e.fs.capture_records()),1)
    def test_share_multiple_choose_one(self):
        a=image('A');c=image('C');e=run(incoming=[a,c],choices=[1])
        self.assertEqual(len(e.fs.capture_records()),1)
        data=base64.b64decode(record(e.fs)['image']);self.assertEqual(data,c.data)
    def test_empty_ocr_still_creates_photo(self):
        e=add(ocr='');self.assertEqual(record(e.fs)['title'],'Untitled Capture');self.assertEqual(record(e.fs)['text'],'')
    def test_duplicate_no_write_or_popup(self):
        e=add();writes=len(e.fs.writes);before=record(e.fs);again=add(e.fs)
        self.assertEqual(record(e.fs),before);self.assertEqual(len(e.fs.writes),writes);self.assertFalse(again.alerts)
    def test_all_captures_select_second_file(self):
        e=add(ocr='First photo');e=run(e.fs,incoming=image('Second'),ocr='Second photo')
        e=resume(e.fs,['📄 View Text'],choices=[1])
        self.assertEqual(e.results,['First photo'])
    def test_rename_title_only(self):
        e=add();before=record(e.fs);writes=len(e.fs.writes)
        e=resume(e.fs,['✏️ Rename Capture'],asks=['New title'])
        r=record(e.fs);self.assertEqual(r['title'],'New title');self.assertEqual(r['text'],before['text']);self.assertEqual(r['image'],before['image'])
        self.assertEqual(len(e.fs.writes),writes+1);self.assertFalse(e.alerts)
    def test_edit_text(self):
        e=add();e=resume(e.fs,['📝 Edit Text'],asks=['Corrected OCR'])
        self.assertEqual(record(e.fs)['text'],'Corrected OCR')
    def test_old_pending_record_has_no_warning(self):
        e=restore_file(exported(legacy(record(add().fs))))
        writes=len(e.fs.writes);e=resume(e.fs,['⚡ Take Action','📋 Copy Text'],asks=['Copied'])
        self.assertFalse(e.alerts);self.assertIn(('clipboard','Copied'),e.effects);self.assertEqual(len(e.fs.writes),writes)
    def test_reminder_without_date(self):
        e=add();before=dict(e.fs.files);e=resume(e.fs,['⚡ Take Action','🔔 Create Reminder','📥 No Due Date'],asks=['Buy tickets'])
        p=next(p for a,p in e.effects if a=='addnewreminder');self.assertEqual(p['WFCalendarItemTitle'],'Buy tickets')
        self.assertEqual(p['WFAlertEnabled'],'No Alert');self.assertIsNone(p['WFImages'])
        self.assertEqual(e.fs.files,before);self.assertFalse(e.alerts)
    def test_reminder_day_only_returns_to_action_menu(self):
        e=add();e=resume(e.fs,['⚡ Take Action','🔔 Create Reminder','📅 Choose Day','↩️ Back to Capture','🏠 Main Menu','⏹ Quit'],asks=['Call','2026-11-15T00:00:00-07:00'])
        p=next(p for a,p in e.effects if a=='addnewreminder')
        self.assertEqual(p['WFAlertCustomTime'],'2026-11-15T00:00:00-07:00');self.assertIsNone(p['WFImages'])
        self.assertEqual(e.outcome,'stopped');self.assertFalse(e.asks)
    def test_no_title_returns_to_actions(self):
        e=add();e=resume(e.fs,['⚡ Take Action','🔔 Create Reminder','📋 Copy Text','↩️ Back to Capture','🏠 Main Menu','⏹ Quit'],asks=['','Next task'])
        self.assertFalse(any(a=='addnewreminder' for a,_ in e.effects));self.assertIn(('clipboard','Next task'),e.effects)
        self.assertEqual(e.outcome,'stopped')
    def test_no_address_returns_to_action_menu(self):
        e=add();e=resume(e.fs,['⚡ Take Action','🗺 Find an Address','📋 Copy Text','↩️ Back to Capture','🏠 Main Menu','⏹ Quit'],asks=['Returned'])
        self.assertTrue(any(t=='No address found' for t,_,_ in e.alerts));self.assertIn(('clipboard','Returned'),e.effects)
        self.assertEqual(e.outcome,'stopped')
    def test_every_output_returns_to_action_menu(self):
        ai={'title':'Example','text':'Visit https://example.com','summary':'Example',
            'address':'123 Main Street','contactFirstName':'Jane','contactLastName':'Doe',
            'contactCompany':'','contactPhone':'','contactEmail':'','contactNotes':''}
        cases=[('🔔 Create Reminder',['📥 No Due Date'],['Task']),('📅 Create Calendar Event',[],['2026-11-15T12:00:00-07:00']),
               ('☑️ Create Checklist',[],['Task one']),('📝 Save to Notes',[],[]),('📋 Copy Text',[],['Copied']),
               ('🗺 Find an Address',[],[]),('🔗 Open a Web Link',[],[]),('👤 Create Contact',[],[]),
               ('🔊 Read Text Aloud',[],[]),('📑 Export PDF',[],[])]
        for name,extra,answers in cases:
            with self.subTest(output=name):
                first=add(model_result=ai)
                e=resume(first.fs,['⚡ Take Action',name]+extra+['↩️ Back to Capture','🏠 Main Menu','⏹ Quit'],asks=answers)
                self.assertEqual(e.outcome,'stopped')
                self.assertFalse(e.menus)
    def test_calendar_single_date_time_and_calendar_selection(self):
        e=add(ocr='Dentist');before=dict(e.fs.files)
        e=resume(e.fs,['⚡ Take Action','📅 Create Calendar Event'],asks=['2026-11-15T19:45:00-07:00'],selected_calendar='Work')
        p=next(p for a,p in e.effects if a=='addnewevent');self.assertTrue(p['ShowWhenRun']);self.assertFalse(p['WFCalendarItemAllDay'])
        self.assertEqual(p['WFCalendarItemTitle'],'Dentist');self.assertEqual(p['WFCalendarItemStartDate'],'2026-11-15T19:45:00-07:00')
        self.assertEqual(dt.datetime.fromisoformat(p['WFCalendarItemEndDate'])-dt.datetime.fromisoformat(p['WFCalendarItemStartDate']),dt.timedelta(hours=1))
        self.assertEqual(p['WFCalendarDescriptor'],'Work');self.assertEqual(e.fs.files,before)
        self.assertFalse(e.asks);self.assertFalse(e.alerts)
    def test_checklist(self):
        e=add();before=dict(e.fs.files);e=resume(e.fs,['⚡ Take Action','☑️ Create Checklist'],asks=['Milk\nBread\nEggs'],choices=['first','all'])
        tasks=[p['WFCalendarItemTitle'] for a,p in e.effects if a=='addnewreminder'];self.assertEqual(tasks,['Milk','Bread','Eggs']);self.assertEqual(e.fs.files,before)
    def test_notes_passes_recognized_text_to_iphone_action(self):
        e=add(ocr='Dentist\nBring insurance card');e=resume(e.fs,['⚡ Take Action','📝 Save to Notes'])
        p=next(p for a,p in e.effects if a=='create-note')
        self.assertIn('Dentist',p['WFCreateNoteInput']);self.assertIn('Bring insurance card',p['WFCreateNoteInput'])
        self.assertFalse(any(a=='share' for a,_ in e.effects));self.assertFalse(e.alerts)
    def test_home_quit_is_last_and_stops(self):
        e=run(menus=['⏹ Quit'])
        self.assertEqual(e.outcome,'stopped')
    def test_copy_text(self):
        e=add();e=resume(e.fs,['⚡ Take Action','📋 Copy Text'],asks=['Specific words'])
        self.assertIn(('clipboard','Specific words'),e.effects)
    def test_maps_uses_recognized_address_without_prompt(self):
        ai={'title':'Dinner','text':'Cafe 123\n123 Main Street, Salt Lake City, UT','summary':'Dinner reservation.',
            'address':'123 Main Street, Salt Lake City, UT','contactFirstName':'','contactLastName':'',
            'contactCompany':'','contactPhone':'','contactEmail':'','contactNotes':''}
        e=add(model_result=ai);e=resume(e.fs,['⚡ Take Action','🗺 Find an Address'])
        url=next(p for a,p in e.effects if a=='openurl');self.assertIn('123%20Main%20Street',url);self.assertNotIn('Address to find',str(e.asks))
    def test_links(self):
        e=add(ocr='Read https://example.com/info');e=resume(e.fs,['⚡ Take Action','🔗 Open a Web Link'])
        self.assertIn(('openurl','https://example.com/info'),e.effects);self.assertFalse(e.alerts)
    def test_contact_uses_recognized_details_without_prompt(self):
        ai={'title':'Business Card','text':'Jamie Doe\n555-0100\njamie@example.com','summary':'Jamie Doe contact details.',
            'address':'','contactFirstName':'Jamie','contactLastName':'Doe','contactCompany':'ACME',
            'contactPhone':'555-0100','contactEmail':'jamie@example.com','contactNotes':'Sales contact'}
        e=add(model_result=ai);e=resume(e.fs,['⚡ Take Action','👤 Create Contact'])
        p=next(p for a,p in e.effects if a=='addnewcontact');self.assertEqual(p['WFContactFirstName'],'Jamie')
        self.assertEqual(p['WFContactLastName'],'Doe');self.assertEqual(p['WFContactCompany'],'ACME')
        self.assertIn('555-0100',p['WFContactNotes']);self.assertIn('jamie@example.com',p['WFContactNotes'])
        self.assertTrue(p['ShowWhenRun']);self.assertFalse(e.asks)
    def test_empty_address_does_not_prompt(self):
        e=add();e=resume(e.fs,['⚡ Take Action','🗺 Find an Address'])
        self.assertFalse(any(a=='openurl' for a,_ in e.effects));self.assertFalse(e.asks)
        self.assertTrue(any('No address found' in title for title,_,_ in e.alerts))
    def test_speech(self):
        e=add(ocr='Read this');e=resume(e.fs,['⚡ Take Action','🔊 Read Text Aloud'])
        self.assertIn(('speak','Read this'),e.effects)
    def test_pdf(self):
        e=add();e=resume(e.fs,['⚡ Take Action','📑 Export PDF'])
        p=next(p for a,p in e.effects if a=='pdf-input');self.assertIsInstance(p[0],File)
        self.assertIsInstance(next(p for a,p in e.effects if a=='share'),File)
    def test_view_photo(self):
        e=add();e=resume(e.fs,['🖼 View Photo']);self.assertTrue(any(a=='preview' for a,_ in e.effects))
    def test_view_text(self):
        e=add(ocr='Some text');e=resume(e.fs,['📄 View Text']);self.assertEqual(e.results,['Some text'])
    def test_backup_real_zip(self):
        e=add();e=run(e.fs,menus=['💾 Backup and Restore','💾 Create Backup'])
        backup=next(d for p,d in e.fs.files.items() if '/Backups/' in p)
        with zipfile.ZipFile(io.BytesIO(backup)) as z:
            self.assertEqual(len(z.namelist()),1);self.assertEqual(json.loads(z.read(z.namelist()[0])),record(e.fs))
        self.assertTrue(any(a=='share' for a,_ in e.effects))
    def test_backup_restores_multiple_captures(self):
        e=run(incoming=image('First'),ocr='First capture')
        e=run(e.fs,incoming=image('Second'),ocr='Second capture')
        expected=list(e.fs.capture_records().values())
        e=run(e.fs,menus=['💾 Backup and Restore','💾 Create Backup'])
        archive=next(d for path,d in e.fs.files.items() if '/Backups/' in path)
        recovered=restore_file(File('backup.zip',archive))
        actual=list(recovered.fs.capture_records().values())
        self.assertEqual({x['id'] for x in actual},{x['id'] for x in expected})
        self.assertEqual({x['text'] for x in actual},{x['text'] for x in expected})
    def test_restore_legacy_image_bytes_hash(self):
        original=record(add(ocr='Legacy capture').fs).copy()
        original['schema']='2'
        original['id']=hashlib.sha256(base64.b64decode(original['image'])).hexdigest()
        restored=restore_file(exported(original))
        self.assertEqual(record(restored.fs),original)
    def test_restore_v2(self):
        r=record(add().fs);e=restore_file(exported(r));self.assertEqual(record(e.fs),r)
    def test_file_json_is_converted_to_text_before_dictionary_parse(self):
        actions=Engine(SHORTCUT).actions
        for i,a in enumerate(actions):
            if a['WFWorkflowActionIdentifier'].endswith('.detect.dictionary'):
                source=a['WFWorkflowActionParameters']['WFInput']['Value']
                self.assertEqual(source.get('Type'),'ActionOutput')
                producer=next(x for x in actions if x['WFWorkflowActionParameters']['UUID']==source['OutputUUID'])
                self.assertTrue(producer['WFWorkflowActionIdentifier'].endswith('.detect.text'))
    def test_restore_legacy_preserves_image_and_title(self):
        r=legacy(record(add().fs));e=restore_file(exported(r));self.assertEqual(record(e.fs),r)
    def test_restore_skip_existing(self):
        e=add();r=record(e.fs);e=restore_file(exported({**r,'title':'Do not overwrite'}),e.fs)
        self.assertEqual(record(e.fs),r)
    def test_restore_duplicate_inside_zip(self):
        r=record(add().fs);e=restore_file(zip_records([r,r]));self.assertEqual(len(e.fs.capture_records()),1)
    def test_delete_with_confirmation(self):
        e=add();e=resume(e.fs,['🗑 Delete Capture']);self.assertFalse(e.fs.capture_records())
        self.assertTrue(any(t=='🗑 Delete this capture?' and c for t,_,c in e.alerts))
    def test_delete_includes_legacy_recovery(self):
        e=add();r=record(e.fs);e.fs.folder('/Shortcuts/Screenshot to Action/Recovery')
        path='/Shortcuts/Screenshot to Action/Recovery/'+r['id']+'.json';e.fs.save(path,json.dumps(r).encode())
        e=resume(e.fs,['🗑 Delete Capture']);self.assertNotIn(path,e.fs.files)
    def test_about_and_github(self):
        e=run(menus=['ℹ️ About and Help','📖 How to Use','🐙 SurfKraken on GitHub',MAIN])
        self.assertIn('SurfKraken',e.results[0]);self.assertIn(('openurl','https://github.com/surfkraken'),e.effects)
        self.assertFalse(e.fs.writes);self.assertEqual(e.fs.dirs,{'/Shortcuts'})
    def test_navigation_back_buttons(self):
        e=add();e=resume(e.fs,['⚡ Take Action','↩️ Back to Capture',MAIN,'💾 Backup and Restore',MAIN])
        self.assertEqual(len(e.fs.capture_records()),1)

if __name__=='__main__':unittest.main(verbosity=2)
