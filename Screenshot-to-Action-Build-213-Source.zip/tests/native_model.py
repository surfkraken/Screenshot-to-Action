"""Control-flow/data model for the *serialized* native shortcut, not an iOS runtime.

Filesystem, JSON, SHA-256, base64 and ZIP behavior run for real in memory.
Apple UI, OCR and app actions are explicit test doubles. This cannot prove import
compatibility or replace a device test; it does expose routing/data-loss defects.
"""
from __future__ import annotations
import base64, copy, datetime as dt, hashlib, io, json, pathlib, plistlib, re, zipfile
from dataclasses import dataclass
from PIL import Image,ImageDraw

class Cancelled(Exception):pass
class Stopped(Exception):pass
class InjectedFailure(Exception):pass
class UnexpectedUI(Exception):pass

COVERED_ACTIONS=set()
COVERED_MENU_CASES=set()

@dataclass
class File:
    name:str
    data:bytes=b''
    path:str|None=None
    folder:bool=False

def image(text='Appointment Nov 15, 2026 at 3 PM',color='white'):
    im=Image.new('RGB',(600,200),color);ImageDraw.Draw(im).text((20,20),text,fill='black')
    out=io.BytesIO();im.save(out,format='PNG');return File('Screenshot.png',out.getvalue())

def text(x):
    if x is None:return ''
    if isinstance(x,File):
        try:return x.data.decode('utf-8')
        except UnicodeDecodeError:return x.name
    if isinstance(x,dict):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
    if isinstance(x,list):return '\n'.join(text(y) for y in x)
    if isinstance(x,dt.datetime):return x.isoformat()
    return str(x)

def raw(x):
    if isinstance(x,File):return x.data
    return text(x).encode()

def items(x):
    if x is None or x=='':return []
    return x if isinstance(x,list) else [x]

class FS:
    def __init__(self):self.files={};self.dirs={'/Shortcuts'};self.clock=0;self.versions={};self.writes=[];self.deletes=[]
    def folder(self,path):
        path=path.rstrip('/');self.dirs.add(path);return File(path.split('/')[-1],path=path,folder=True)
    def get(self,path):
        if path in self.dirs:return self.folder(path)
        return File(path.rsplit('/',1)[-1],self.files[path],path) if path in self.files else None
    def save(self,path,data,overwrite=True):
        if not overwrite and path in self.files:raise FileExistsError(path)
        self.clock+=1;self.files[path]=data;self.versions[path]=self.clock;self.writes.append(path)
        return self.get(path)
    def children(self,path):
        prefix=path.rstrip('/')+'/'
        return [self.get(p) for p in self.files if p.startswith(prefix) and '/' not in p[len(prefix):]]
    def capture_records(self):
        return {p:json.loads(d) for p,d in self.files.items() if '/Captures/' in p and p.endswith('.json')}

class Engine:
    def __init__(self,shortcut,fs=None,menus=None,asks=None,choices=None,photos=None,selected_files=None,
                 incoming=None,ocr='Example appointment\nRemember the tickets',cancel_alert=None,
                 fail_action=None,fail_occurrence=1,cancel_native=None,dates=None,selected_calendar='Personal',model_result=None):
        self.p=plistlib.loads(pathlib.Path(shortcut).read_bytes());self.actions=self.p['WFWorkflowActions'];self.fs=fs or FS()
        self.menus=list(menus or []);self.asks=list(asks or []);self.choices=list(choices or [])
        self.photos=list(photos or []);self.selected_files=list(selected_files or [])
        self.incoming=incoming;self.ocr=ocr;self.cancel_alert=cancel_alert;self.fail_action=fail_action
        self.model_result=model_result
        self.fail_occurrence=fail_occurrence;self.cancel_native=cancel_native;self.dates=list(dates or []);self.selected_calendar=selected_calendar
        self.vars={};self.outputs={};self.alerts=[];self.effects=[];self.results=[];self.executed=set();self.hits={}
        self.now_counter=0;self.blocks={};self.stack=[];self.active_each=[];self.repeat_depth=0;self.last_delete_confirmation=False
        self.action_counts={};self.outcome='not-run'
        for i,a in enumerate(self.actions):
            p=a['WFWorkflowActionParameters'];mode=p.get('WFControlFlowMode')
            if mode==0:self.stack.append([i,[]])
            elif mode==1:self.stack[-1][1].append(i)
            elif mode==2:
                start,middle=self.stack.pop();self.blocks[start]=(middle,i)
        assert not self.stack
    def resolve(self,p):
        if isinstance(p,dict):
            ser=p.get('WFSerializationType')
            if ser=='WFTextTokenAttachment':return self.resolve(p['Value'])
            if ser=='WFTextTokenString':
                val=p['Value'];s=val['string'];buf=s.encode('utf-16-le')
                for key,ref in sorted(val.get('attachmentsByRange',{}).items(),key=lambda kv:int(re.findall(r'\d+',kv[0])[0]),reverse=True):
                    start,length=map(int,re.findall(r'\d+',key));replacement=text(self.resolve(ref)).encode('utf-16-le')
                    buf=buf[:start*2]+replacement+buf[(start+length)*2:]
                return buf.decode('utf-16-le')
            if ser=='WFDictionaryFieldValue':
                return {self.resolve(i['WFKey']):self.resolve(i['WFValue']) for i in p['Value'].get('WFDictionaryFieldValueItems',[])}
            typ=p.get('Type')
            if typ=='Variable' and 'VariableName' in p:return copy.deepcopy(self.vars.get(p['VariableName']))
            if typ=='Variable' and 'Variable' in p:return self.resolve(p['Variable'])
            if typ=='ActionOutput':
                if p['OutputUUID'] not in self.outputs:raise AssertionError('Unexecuted output reference '+p['OutputUUID'])
                return copy.deepcopy(self.outputs[p['OutputUUID']])
            if typ=='ExtensionInput':return self.incoming
            if typ=='Ask':return self.selected_calendar
            if p.get('fileLocation',{}).get('WFFileLocationType')=='Shortcuts':return self.fs.folder('/Shortcuts')
            return {k:self.resolve(x) for k,x in p.items()}
        if isinstance(p,list):return [self.resolve(x) for x in p]
        return p
    def condition(self,p):
        inp=self.resolve(p['WFInput']);code=p['WFCondition'];val=self.resolve(p.get('WFConditionalActionString',p.get('WFNumberValue')))
        if code==100:return bool(items(inp))
        if code==101:return not bool(items(inp))
        if code==4:return text(inp)==text(val)
        if code==5:return text(inp)!=text(val)
        if code==8:return text(inp).startswith(text(val))
        if code==9:return text(inp).endswith(text(val))
        if code==99:return text(val) in text(inp)
        if code==999:return text(val) not in text(inp)
        if code in (0,1,2,3):
            n=float(text(inp));v=float(text(val));return {0:n<v,1:n<=v,2:n>v,3:n>=v}[code]
        raise NotImplementedError(code)
    def run(self):
        try:self.segment(0,len(self.actions));self.outcome='finished'
        except Stopped:self.outcome='stopped'
        except Cancelled:self.outcome='cancelled'
        except InjectedFailure:self.outcome='injected-failure'
        return self
    def segment(self,start,end):
        i=start
        while i<end:
            a=self.actions[i];ident=a['WFWorkflowActionIdentifier'];p=a['WFWorkflowActionParameters'];self.executed.add(i)
            COVERED_ACTIONS.add(i)
            self.action_counts[ident]=self.action_counts.get(ident,0)+1
            if self.action_counts[ident]>20000:raise AssertionError('Unexpected infinite navigation')
            if ident.endswith('conditional') and p.get('WFControlFlowMode')==0:
                middle,stop=self.blocks[i];split=middle[0] if middle else stop
                if self.condition(p):self.segment(i+1,split)
                elif middle:self.segment(split+1,stop)
                result=None;i=stop+1;continue
            if ident.endswith('choosefrommenu') and p.get('WFControlFlowMode')==0:
                middle,stop=self.blocks[i];labels=p['WFMenuItems']
                if self.menus:
                    choice=self.menus.pop(0)
                    if choice is Cancelled:raise Cancelled()
                    if choice not in labels:raise UnexpectedUI(f'Expected {choice!r}, got menu {labels!r}')
                else:raise Cancelled()
                self.effects.append(('menu',{'prompt':self.resolve(p['WFMenuPrompt']),'choice':choice}))
                n=labels.index(choice);COVERED_MENU_CASES.add(middle[n]);self.segment(middle[n]+1,middle[n+1] if n+1<len(middle) else stop)
                i=stop+1;continue
            if ident.endswith(('repeat.each','repeat.count')) and p.get('WFControlFlowMode')==0:
                middle,stop=self.blocks[i]
                if ident.endswith('repeat.each'):
                    values=items(self.resolve(p['WFInput']));depth=len(self.active_each)+1
                    depth=self.repeat_depth+1
                    key='Repeat Item'+(' '+str(depth) if depth>1 else '')
                    self.active_each.append(key);self.repeat_depth+=1
                    for item in values:
                        self.vars[key]=copy.deepcopy(item);self.segment(i+1,stop)
                    self.active_each.pop();self.repeat_depth-=1
                else:
                    self.repeat_depth+=1
                    for _ in range(int(self.resolve(p['WFRepeatCount']))):self.segment(i+1,stop)
                    self.repeat_depth-=1
                i=stop+1;continue
            result=self.step(ident,p)
            self.outputs[p['UUID']]=copy.deepcopy(result);i+=1
    def step(self,ident,p):
        name=ident.removeprefix('is.workflow.actions.');P=lambda key,default=None:self.resolve(p.get(key,default))
        if self.fail_action==name:
            self.hits[name]=self.hits.get(name,0)+1
            if self.hits[name]==self.fail_occurrence:raise InjectedFailure(name)
        if name in ('comment','nothing'):return None
        if name=='gettext':return P('WFTextActionText')
        if name=='setvariable':self.vars[p['WFVariableName']]=P('WFInput');return None
        if name=='appendvariable':
            key=p['WFVariableName'];self.vars[key]=items(self.vars.get(key))+items(P('WFInput'));return None
        if name=='dictionary':return P('WFItems')
        if name=='detect.dictionary':
            data=P('WFInput');return copy.deepcopy(data) if isinstance(data,dict) else json.loads(raw(data))
        if name=='askllm':
            if self.model_result is not None:return copy.deepcopy(self.model_result)
            transcript=self.ocr or ''
            first=next((line.strip() for line in transcript.splitlines() if line.strip()),'')
            return {'title':first[:80],'text':transcript,'summary':first,'address':'',
                    'contactFirstName':'','contactLastName':'','contactCompany':'',
                    'contactPhone':'','contactEmail':'','contactNotes':''}
        if name=='getvalueforkey':
            data=P('WFInput');typ=p.get('WFGetDictionaryValueType','Value')
            if typ=='All Keys':return list(data)
            if typ=='All Values':return list(data.values())
            return data.get(P('WFDictionaryKey'))
        if name=='setvalueforkey':
            assert not isinstance(p['WFDictionaryValue'],dict) or p['WFDictionaryValue'].get('WFSerializationType')=='WFTextTokenString','Wrong native Value serialization'
            data=copy.deepcopy(P('WFDictionary'));data[P('WFDictionaryKey')]=P('WFDictionaryValue');return data
        if name=='detect.text':return text(P('WFInput'))
        if name=='ask':
            if self.asks:val=self.asks.pop(0)
            else:val=next((P(k) for k in ('WFAskActionDefaultAnswer','WFAskActionDefaultAnswerDateAndTime','WFAskActionDefaultAnswerNumber') if k in p),'')
            if val is Cancelled:raise Cancelled()
            return val
        if name=='choosefromlist':
            data=items(P('WFInput'));choice=self.choices.pop(0) if self.choices else 'first'
            if choice is Cancelled:raise Cancelled()
            if callable(choice):return choice(data)
            if choice=='all':return data
            if choice=='first':return data[0]
            if isinstance(choice,int):return data[choice]
            assert choice in data,(choice,data);return choice
        if name=='alert':
            title=P('WFAlertActionTitle');message=P('WFAlertActionMessage');cancel=p.get('WFAlertActionCancelButtonShown',False)
            self.alerts.append((title,message,cancel))
            if title==self.cancel_alert:raise Cancelled()
            if cancel and ('Delete' in title or 'delete' in title):self.last_delete_confirmation=True
            return None
        if name=='exit':raise Stopped()
        if name=='selectphoto':return self.photos.pop(0) if self.photos else []
        if name=='takephoto':
            if self.cancel_native=='takephoto':raise Cancelled()
            return self.photos.pop(0) if self.photos else image('Camera photo')
        if name=='file.select':return self.selected_files.pop(0)
        if name=='file.createfolder':return self.fs.folder(P('WFFolder').path+'/'+P('WFFilePath'))
        if name=='documentpicker.open':
            folder=P('WFFile');path=folder.path+'/'+P('WFGetFilePath').lstrip('/')
            result=self.fs.get(path)
            if result is None and p.get('WFFileErrorIfNotFound'):raise FileNotFoundError(path)
            return self.fs.children(path) if result and result.folder and p.get('WFGetFolderContents') else result
        if name=='setitemname':
            source=P('WFInput');return File(P('WFName'),raw(source))
        if name=='documentpicker.save':
            folder=P('WFFolder');source=P('WFInput');name=P('WFFileDestinationPath')
            assert '/' not in name and '..' not in name,('Unsafe subpath',name)
            return self.fs.save(folder.path+'/'+name,raw(source),p.get('WFSaveFileOverwrite',False))
        if name=='file.getfoldercontents':return self.fs.children(P('WFFolder').path)
        if name=='filter.files':
            data=items(P('WFContentItemInputParameter'));data=[f for f in data if f.name.endswith('.json')]
            return sorted(data,key=lambda f:self.fs.versions.get(f.path,0),reverse=True)
        if name=='file.delete':
            assert self.last_delete_confirmation,'Delete without explicit confirmation'
            if self.cancel_native=='file.delete':raise Cancelled()
            for f in items(P('WFInput')):
                assert f.path.startswith('/Shortcuts/Screenshot to Action/'),f.path
                self.fs.deletes.append(f.path);self.fs.files.pop(f.path,None)
            self.last_delete_confirmation=False;return None
        if name=='properties.files':
            f=P('WFInput');prop=p['WFContentItemPropertyName']
            return {'File Extension':f.name.rsplit('.',1)[-1] if '.' in f.name else '',
                    'Name':f.name,'File Size':len(f.data),'File Path':f.path}.get(prop)
        if name=='detect.images':
            result=[]
            for x in items(P('WFInput')):
                try:
                    im=Image.open(io.BytesIO(raw(x)));im.verify();result.append(x if isinstance(x,File) else File('Image.png',raw(x)))
                except Exception:pass
            return result
        if name=='image.convert':
            # Real PNG conversion, using Pillow rather than Apple's image service.
            im=Image.open(io.BytesIO(raw(P('WFInput'))));out=io.BytesIO();im.save(out,format='PNG');return File('Image.png',out.getvalue())
        if name=='extracttextfromimage':
            assert P('imageFile') is not None,'Missing OCR image'
            if callable(self.ocr):return self.ocr(P('imageFile'))
            return self.ocr
        if name=='base64encode':
            source=P('WFInput')
            if p['WFEncodeMode']=='Encode':return base64.b64encode(raw(source)).decode()
            return File('Decoded',base64.b64decode(text(source),validate=True))
        if name=='hash':return hashlib.sha256(raw(P('WFInput'))).hexdigest()
        if name=='text.changecase':return text(P('text')).lower() if p['WFCaseType']=='lowercase' else text(P('text')).upper()
        if name=='text.trimwhitespace':return text(P('WFInput')).strip()
        if name=='text.split':return text(P('text')).split('\n')
        if name=='text.combine':return P('WFTextCustomSeparator','\n').join(text(x) for x in items(P('text')))
        if name=='text.match':return [m.group(0) for m in re.finditer(P('WFMatchTextPattern'),text(P('text')),0 if p.get('WFMatchTextCaseSensitive') else re.I)]
        if name=='text.replace':return re.sub(P('WFReplaceTextFind'),P('WFReplaceTextReplace'),text(P('WFInput')),flags=0 if p.get('WFReplaceTextCaseSensitive') else re.I)
        if name=='getitemfromlist':
            data=items(P('WFInput'))
            index=int(text(P('WFItemIndex')))-1 if p.get('WFItemSpecifier')=='Item At Index' else 0
            return data[index] if data else None
        if name=='count':return len(items(P('Input')))
        if name=='math':
            n=float(text(P('WFInput')))+float(text(P('WFMathOperand')));return int(n) if n.is_integer() else n
        if name=='list':return P('WFItems')
        if name=='date':
            self.now_counter+=1;return dt.datetime(2026,11,11,18,0,0,self.now_counter*1000,tzinfo=dt.timezone.utc)
        if name=='format.date':
            source=P('WFDate')
            if isinstance(source,str):source=dt.datetime.fromisoformat(source)
            fmt=p.get('WFDateFormat')
            if fmt=='yyyy-MM-dd':return source.strftime('%Y-%m-%d')
            if fmt=='yyyyMMdd-HHmmss-SSS':return source.strftime('%Y%m%d-%H%M%S-')+str(source.microsecond//1000).zfill(3)
            if fmt=='MMM d, yyyy h:mm a':return source.strftime('%b %d, %Y %I:%M %p')
            return source.isoformat(timespec='seconds')
        if name=='adjustdate':
            source=P('WFDate')
            if isinstance(source,str):source=dt.datetime.fromisoformat(source)
            duration=p['WFDuration']['Value'];amount=float(duration['Magnitude'])
            return source+dt.timedelta(seconds=amount*{'hr':3600,'min':60,'sec':1}[duration['Unit']])
        if name=='gettimebetweendates':
            start=dt.datetime.fromisoformat(P('WFTimeUntilFromDate'));end=dt.datetime.fromisoformat(P('WFInput'));return (end-start).total_seconds()/60
        if name=='detect.date':
            source=text(P('WFInput'))
            try:return [dt.datetime.strptime(source,'%Y-%m-%d %I:%M %p')]
            except ValueError:return self.dates
        if name in ('addnewreminder','addnewevent','addnewcontact'):
            if self.cancel_native==name:raise Cancelled()
            payload={k:P(k) for k in p if k!='UUID'}
            self.effects.append((name,payload));return {'nativeObject':name,'index':len(self.effects)}
        if ident=='com.apple.mobilenotes.SharingExtension':
            payload={k:P(k) for k in p if k!='UUID'}
            self.effects.append(('create-note',payload));return {'nativeObject':'note'}
        if ident=='com.apple.Notes.CreateNoteIntent':
            payload={k:P(k) for k in p if k!='UUID'}
            self.effects.append(('create-note',payload));return {'nativeObject':'note','index':len(self.effects)}
        if name=='createnote':
            payload={k:P(k) for k in p if k!='UUID'}
            self.effects.append(('create-note',payload));return {'nativeObject':'note','index':len(self.effects)}
        if name=='share':self.effects.append(('share',P('WFInput')));return None
        if name=='showresult':self.results.append(P('Text'));return None
        if name=='previewdocument':self.effects.append(('preview',P('WFInput')));return None
        if name=='speaktext':self.effects.append(('speak',P('WFText')));return None
        if name=='setclipboard':self.effects.append(('clipboard',P('WFInput')));return None
        if name=='urlencode':
            import urllib.parse
            return urllib.parse.quote(P('WFInput'),safe='')
        if name=='url':return P('WFURLActionURL')
        if name=='openurl':self.effects.append(('openurl',P('WFInput')));return None
        if name=='detect.link':return re.findall(r'(?:https?://|tel:)[^\s]+',text(P('WFInput')))
        if name=='makepdf':self.effects.append(('pdf-input',P('WFInput')));return File('PDF.pdf',b'%PDF-MOCK-Apple-renderer-not-executed')
        if name=='makezip':
            out=io.BytesIO()
            with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
                for f in items(P('WFInput')):z.writestr(f.name,f.data)
            return File(P('WFZIPName')+'.zip',out.getvalue())
        if name=='unzip':
            with zipfile.ZipFile(io.BytesIO(raw(P('WFArchive')))) as z:return [File(n,z.read(n)) for n in z.namelist() if not n.endswith('/')]
        raise NotImplementedError(name)
