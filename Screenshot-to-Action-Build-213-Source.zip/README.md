# Screenshot to Action

Version 2.0, Build 213. Created by SurfKraken.

An Apple Shortcut that saves a screenshot, extracts useful details, and offers direct next steps.

## Main menu

The first menu displays the tagline “See it. Sort it. Save it.” and these options:

1. Choose Photo
2. Take a Photo
3. All Captures
4. Backup and Restore
5. About and Help
6. Quit

You can also run it from the share sheet with an image. Each capture uses one image.

## Captures and analysis

Captures are stored in `iCloud Drive/Shortcuts/Screenshot to Action/Captures`. Each record includes the image, editable title, recognized text, summary, detected address and contact details, and integrity identifier. Use All Captures to review, rename, edit text, or delete a capture. Deletion asks for confirmation.

Image analysis uses Apple's Shortcuts Use Model action with Apple Private Cloud Compute. It needs a supported Apple Intelligence device, internet access, and available service capacity. Analysis output and native app actions must be verified on the target iPhone.

## Actions

From a saved capture, choose an action:

- Create a Reminder in Apple Reminders, with an optional day and no time question.
- Create a calendar event with one day-and-time question, a calendar picker, and a one-hour default duration.
- Create checklist reminders, up to 50 selected lines.
- Save to Notes, passing the title, summary, recognized text, and image to the Notes action. Confirm on-device that Notes displays both text and image as intended.
- Copy or read the capture text aloud.
- Open a detected address in Maps, open a detected web link, or create a contact prefilled with detected details.
- Export a PDF through the share sheet.

Completed actions and recoverable validation messages return to the relevant shortcut menu. Native cancellations, permissions, or service errors can still interrupt a run. The shortcut does not record an action history or rewrite the capture archive when an output is selected.

## Backup and restore

Backups are saved in `iCloud Drive/Shortcuts/Screenshot to Action/Backups` as ZIP files and can be shared for safekeeping. Restore accepts ZIP or individual JSON capture files. It validates all records and image IDs before importing, skips captures already present, and does not recreate reminders, calendar events, or contacts. Supported capture schema versions are 1, 2, and 3. Legacy recovery files are not included in new backups.

## Verification and known limits

The build has 93 automated structural and modeled workflow checks, including all 32 menu branches and backup/restore cases. They run against the generated shortcut data and simulated Apple actions. They do not verify import, actual iPhone performance, Apple Intelligence output, Notes rendering, Reminders behavior, calendar selection, or permissions. See `dist/Screenshot-to-Action-Test-Report.md` for the test report and artifact hash.

## Project credit

[SurfKraken on GitHub](https://github.com/surfkraken)

The project source has not been published to a repository. GitHub backup is pending Andy's approval.
