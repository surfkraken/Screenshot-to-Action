#!/usr/bin/env python3
"""Generate a compact native Screenshot to Action shortcut."""
from __future__ import annotations
import contextlib,json,pathlib,plistlib,re,uuid

ROOT=pathlib.Path(__file__).resolve().parent
NAME='Screenshot to Action'
FORMAT='SurfKraken.ScreenshotToAction'
VERSION='2.0'
BUILD='213'
STEM=f'Screenshot-to-Action-v{VERSION}-Build-{BUILD}'
GITHUB='https://github.com/surfkraken'
ID_RE=r'^[a-f0-9]{64}$'
CATALOG=json.loads((ROOT/'tests/validation_catalog.json').read_text())

def uid():return str(uuid.uuid4()).upper()
def attachment(value):return {'Value':value,'WFSerializationType':'WFTextTokenAttachment'}
def v(name):return attachment({'Type':'Variable','VariableName':name})
def token(*parts):
    """Encode text attachments at Apple's UTF-16 offsets, including emoji."""
    out='';refs={}
    for part in parts:
        start=len(out.encode('utf-16-le'))//2
        if isinstance(part,dict) and part.get('WFSerializationType')=='WFTextTokenString':
            data=part['Value']
            for k,ref in data.get('attachmentsByRange',{}).items():
                pos,length=map(int,re.findall(r'\d+',k));refs['{%d, %d}'%(start+pos,length)]=ref
            out+=data['string']
        elif isinstance(part,dict):
            refs['{%d, 1}'%start]=part.get('Value',part);out+='\ufffc'
        else:out+=str(part)
    return {'Value':{'string':out,'attachmentsByRange':refs},'WFSerializationType':'WFTextTokenString'} if refs else out

def textfield(value):
    if isinstance(value,dict):return value if value.get('WFSerializationType')=='WFTextTokenString' else token(value)
    return str(value)

SHORTCUTS_FOLDER={'displayName':'Shortcuts','filename':'Documents','fileLocation':{
    'WFFileLocationType':'Shortcuts','relativeSubpath':'','appContainerBundleIdentifier':'com.apple.shortcuts',
    'fileProviderDomainID':'com.apple.CloudDocs.MobileDocumentsFileProvider'}}

class Builder:
    def __init__(self):self.actions=[];self.sections={};self.depth=0;self.guards=[];self.guard_failure=None
    def a(self,action_id,**p):
        if not action_id.startswith(('is.workflow.','com.apple.')):action_id='is.workflow.actions.'+action_id
        # Text fields require a token STRING. An attachment alone can import
        # as a blank "Value" chip, despite containing a valid action UUID.
        for spec in CATALOG['tools'].get(action_id,{}).get('parameters',[]):
            key=spec['key']
            if spec['typePythonName'] in ('str','DateTime','URL') and isinstance(p.get(key),dict):p[key]=textfield(p[key])
        if action_id=='is.workflow.actions.math' and p.get('WFMathOperation')=='+':p.pop('WFMathOperation')
        p.setdefault('UUID',uid());self.actions.append({'WFWorkflowActionIdentifier':action_id,'WFWorkflowActionParameters':p})
        output={'gettext':'Text','getvalueforkey':'Dictionary Value','setvalueforkey':'Dictionary','dictionary':'Dictionary',
                'date':'Date','format.date':'Formatted Date','ask':'Provided Input','image.convert':'Converted Image',
                'hash':'Hash','detect.images':'Images','detect.text':'Text','detect.dictionary':'Dictionary',
                'extracttextfromimage':'Text','base64encode':'Base64 Encoded','selectphoto':'Photos','takephoto':'Photo',
                'setitemname':'Renamed Item','documentpicker.save':'Saved File','documentpicker.open':'File',
                'text.match':'Matches','text.replace':'Updated Text','text.changecase':'Updated Text','choosefromlist':'Selected Item','askllm':'Response',
                'getitemfromlist':'Item from List','adjustdate':'Adjusted Date'}.get(action_id.rsplit('is.workflow.actions.',1)[-1],'Result')
        return attachment({'Type':'ActionOutput','OutputUUID':p['UUID'],'OutputName':output})
    def txt(self,*parts):return self.a('gettext',WFTextActionText=token(*parts))
    def set(self,name,value):
        if not isinstance(value,dict):value=self.txt(value)
        self.a('setvariable',WFVariableName=name,WFInput=value);return v(name)
    def empty(self,name):self.set(name,self.a('nothing'))
    def append(self,name,value):self.a('appendvariable',WFVariableName=name,WFInput=value)
    def get(self,key,source='Record',dest=None):
        output=self.a('getvalueforkey',WFGetDictionaryValueType='Value',WFDictionaryKey=textfield(key),WFInput=v(source))
        return self.set(dest,output) if dest else output
    def put(self,key,value,target='Record'):
        return self.set(target,self.a('setvalueforkey',WFDictionaryKey=textfield(key),
                                     WFDictionaryValue=textfield(value),WFDictionary=v(target)))
    def dictionary(self,fields,dest):
        fields=[{'WFItemType':0,'WFKey':textfield(k),'WFValue':textfield(value)} for k,value in fields.items()]
        return self.set(dest,self.a('dictionary',WFItems={'Value':{'WFDictionaryFieldValueItems':fields},'WFSerializationType':'WFDictionaryFieldValue'}))
    @contextlib.contextmanager
    def iff(self,source,condition=100,value=None):
        group=uid();p={'GroupingIdentifier':group,'WFControlFlowMode':0,'WFInput':{'Type':'Variable','Variable':source},'WFCondition':condition}
        if condition in (4,5,99,999):p['WFConditionalActionString']=textfield(value)
        elif condition in (0,1,2,3):p['WFNumberValue']=value
        self.a('conditional',**p)
        class Else:
            def otherwise(inner):self.a('conditional',GroupingIdentifier=group,WFControlFlowMode=1)
        yield Else();self.a('conditional',GroupingIdentifier=group,WFControlFlowMode=2)
    @contextlib.contextmanager
    def each(self,source,item):
        group=uid();self.a('repeat.each',GroupingIdentifier=group,WFControlFlowMode=0,WFInput=source)
        self.depth+=1;self.set(item,v('Repeat Item'+(' '+str(self.depth) if self.depth>1 else '')))
        yield
        self.a('nothing');self.a('repeat.each',GroupingIdentifier=group,WFControlFlowMode=2);self.depth-=1
    @contextlib.contextmanager
    def countloop(self,count):
        group=uid();self.a('repeat.count',GroupingIdentifier=group,WFControlFlowMode=0,WFRepeatCount=count);self.depth+=1
        yield
        self.a('nothing');self.a('repeat.count',GroupingIdentifier=group,WFControlFlowMode=2);self.depth-=1
    def menu(self,prompt,cases):
        group=uid();self.a('choosefrommenu',GroupingIdentifier=group,WFControlFlowMode=0,WFMenuPrompt=prompt,WFMenuItems=[x[0] for x in cases])
        for label,fn in cases:self.a('choosefrommenu',GroupingIdentifier=group,WFControlFlowMode=1,WFMenuItemTitle=label);fn()
        self.a('choosefrommenu',GroupingIdentifier=group,WFControlFlowMode=2)
    def alert(self,title,message,cancel=False):self.a('alert',WFAlertActionTitle=title,WFAlertActionMessage=message,WFAlertActionCancelButtonShown=cancel)
    def stop(self,title=None,message=None):
        if title:self.alert(title,message)
        self.a('exit')
    def require_condition(self,source,condition,value,title,message):
        group=uid();p={'GroupingIdentifier':group,'WFControlFlowMode':0,'WFInput':{'Type':'Variable','Variable':source},'WFCondition':condition}
        if condition in (4,5,99,999):p['WFConditionalActionString']=textfield(value)
        elif condition in (0,1,2,3):p['WFNumberValue']=value
        self.a('conditional',**p);self.guards.append((group,title,message,self.guard_failure))
    def require(self,source,title,message):
        self.require_condition(source,100,None,title,message)
    def guarded(self,fn,on_failure=None):
        def run():
            start=len(self.guards);previous=self.guard_failure;self.guard_failure=on_failure
            fn()
            while len(self.guards)>start:
                group,title,message,failure=self.guards.pop()
                self.a('conditional',GroupingIdentifier=group,WFControlFlowMode=1)
                if title:self.alert(title,message)
                if failure:failure()
                self.a('conditional',GroupingIdentifier=group,WFControlFlowMode=2)
            self.guard_failure=previous
        return run
    def ask(self,prompt,default=None,kind='Text',dest=None,multiline=False):
        # Native WFAskForInputAction stores time selection as granularity of
        # Date. Toolkit enum names alone can import as a date-only picker.
        p={'WFAskActionPrompt':prompt,'WFInputType':'Date' if kind in ('Date','Time','Date and Time') else kind}
        if kind in ('Date','Time','Date and Time'):p['WFAskActionDateGranularity']=kind
        elif kind=='Text':p['WFAllowsMultilineText']=multiline
        if default is not None:
            key='WFAskActionDefaultAnswerDate' if kind in ('Date','Time','Date and Time') else 'WFAskActionDefaultAnswer'
            p[key]=textfield(default)
        output=self.a('ask',**p);return self.set(dest,output) if dest else output
    def choose(self,source,prompt,dest=None,multiple=False):
        output=self.a('choosefromlist',WFInput=source,WFChooseFromListActionPrompt=prompt,WFChooseFromListActionSelectMultiple=multiple)
        return self.set(dest,output) if dest else output
    def now(self,dest):
        date=self.a('date',WFDateActionMode='Current Date')
        return self.set(dest,self.a('format.date',WFDate=token(date),WFDateFormatStyle='ISO 8601',WFISO8601IncludeTime=True))
    def hash(self,source,dest):
        output=self.a('hash',WFInput=source,WFHashType='SHA256')
        return self.set(dest,self.a('text.changecase',text=token(output),WFCaseType='lowercase'))
    def parse(self,source,dest='Record'):
        # Get Dictionary from Input cannot consume Files items in a share-sheet
        # run. Convert the file to text first, then parse the JSON text.
        contents=self.a('detect.text',WFInput=source)
        return self.set(dest,self.a('detect.dictionary',WFInput=contents))
    def getfile(self,folder,path,dest=None,required=False):
        output=self.a('documentpicker.open',WFFile=v(folder) if isinstance(folder,str) else folder,WFGetFilePath=textfield(path),
                      WFShowFilePicker=False,WFFileErrorIfNotFound=required)
        return self.set(dest,output) if dest else output
    def savefile(self,source,folder,name,dest=None,overwrite=True):
        named=self.a('setitemname',WFInput=source,WFName=textfield(name),WFDontIncludeFileExtension=False)
        output=self.a('documentpicker.save',WFInput=named,WFFolder=v(folder),WFAskWhereToSave=False,
                      WFFileDestinationPath=textfield(name),WFSaveFileOverwrite=overwrite)
        return self.set(dest,output) if dest else output
    def records(self,dest='Files'):
        files=self.a('file.getfoldercontents',WFFolder=v('Captures'),Recursive=False)
        return self.set(dest,self.a('filter.files',WFContentItemInputParameter=files,WFContentItemFilter={
            'Value':{'WFActionParameterFilterPrefix':1,'WFActionParameterFilterTemplates':[{
                'Operator':4,'Property':'File Extension','Removable':True,'Values':{'String':'json','Unit':4}}],
                'WFContentPredicateBoundedDate':False},'WFSerializationType':'WFContentPredicateTableTemplate'},
            WFContentItemSortProperty='Last Modified Date',WFContentItemSortOrder='Latest First',WFContentItemLimitEnabled=False))
    def count(self,source,dest):return self.set(dest,self.a('count',Input=source,WFInput=source,WFCountType='Items'))
    def route(self,name):self.set('Screen',name)

b=Builder()

def ensure_folder(name,parent,path):
    b.getfile(parent,path,name)
    with b.iff(v(name),101):
        b.set(name,b.a('file.createfolder',WFFolder=v(parent) if isinstance(parent,str) else parent,WFFilePath=path))

def storage():
    with b.iff(v('AppFolder'),101):
        ensure_folder('AppFolder',SHORTCUTS_FOLDER,NAME);ensure_folder('Captures','AppFolder','Captures')

def save_record():
    # No activity writes, previous-version snapshots, or readback after output
    # actions. Only capture creation and actual user edits touch the archive.
    b.savefile(b.a('detect.text',WFInput=v('Record')),'Captures',token(v('CaptureID'),'.json'),'SelectedFile')

def load_fields():
    b.get('id',dest='CaptureID');b.get('title',dest='Title');b.get('text',dest='Body')
    for key,dest in [('summary','Summary'),('address','Address'),('contactFirstName','ContactFirstName'),
                     ('contactLastName','ContactLastName'),('contactCompany','ContactCompany'),
                     ('contactPhone','ContactPhone'),('contactEmail','ContactEmail'),('contactNotes','ContactNotes')]:
        b.get(key,dest=dest)

def share_image():
    encoded=b.get('image')
    decoded=b.a('base64encode',WFInput=encoded,WFEncodeMode='Decode')
    b.set('CaptureImage',b.a('setitemname',WFInput=decoded,WFName='Capture.png',WFDontIncludeFileExtension=False))

def capture():
    b.route('home');storage();images=b.a('detect.images',WFInput=v('Incoming'));b.set('InputImages',images)
    b.require(v('InputImages'),'No image received','Choose a photo or take a photo to begin.')
    b.count(v('InputImages'),'ImageCount')
    with b.iff(v('ImageCount'),2,1) as branch:
        b.choose(v('InputImages'),'Choose one photo to capture','SourceImage')
        branch.otherwise();b.set('SourceImage',b.a('getitemfromlist',WFInput=v('InputImages'),WFItemSpecifier='First Item'))
    b.set('PNG',b.a('image.convert',WFInput=v('SourceImage'),WFImageFormat='PNG',WFImagePreserveMetadata=False))
    # Hash text, not the native image object. iOS 27 returned an empty hash
    # for some Photos picker items even though OCR could read the image.
    b.set('ImageBase64',b.a('base64encode',WFInput=v('PNG'),WFEncodeMode='Encode',WFBase64LineBreakMode='None'))
    b.hash(v('ImageBase64'),'CaptureID')
    valid=b.a('text.match',text=token(v('CaptureID')),WFMatchTextPattern=ID_RE,WFMatchTextCaseSensitive=True)
    b.require(valid,'Image could not be saved','The image did not produce a valid capture identifier.')
    b.getfile('Captures',token(v('CaptureID'),'.json'),'ExistingCapture')
    with b.iff(v('ExistingCapture')) as branch:
        b.set('SelectedFile',v('ExistingCapture'));b.parse(v('SelectedFile'))
        branch.otherwise()
        prompt=('Analyze the attached photo. Return a dictionary with exactly these string keys: '
                'title, text, summary, address, contactFirstName, contactLastName, contactCompany, '
                'contactPhone, contactEmail, contactNotes. Transcribe visible text faithfully and '
                'preserve line breaks. Make title concise and summary one sentence. Return a postal '
                'address or place name only when clearly visible. Populate contact fields only when '
                'they are visibly present. Never infer or invent missing facts. Use an empty string '
                'for every field that is not clearly present. No Markdown.')
        model=b.a('askllm',WFLLMPrompt=token(prompt,'\n\nPhoto: ',v('PNG')),
                  WFLLMModel='com.apple.Shortcuts.AskMontaraAction',WFGenerativeResultType='Dictionary',FollowUp=False)
        b.set('AIResult',model)
        for key,dest in [('title','Title'),('text','Body'),('summary','Summary'),('address','Address'),
                         ('contactFirstName','ContactFirstName'),('contactLastName','ContactLastName'),
                         ('contactCompany','ContactCompany'),('contactPhone','ContactPhone'),
                         ('contactEmail','ContactEmail'),('contactNotes','ContactNotes')]:
            b.get(key,'AIResult',dest)
        b.set('Title',b.a('text.trimwhitespace',WFInput=token(v('Title'))))
        with b.iff(v('Title'),101):b.set('Title','Untitled Capture')
        b.set('Body',b.a('text.trimwhitespace',WFInput=token(v('Body'))))
        b.set('Summary',b.a('text.trimwhitespace',WFInput=token(v('Summary'))))
        b.now('Created')
        b.dictionary({'format':FORMAT,'schema':'3','id':v('CaptureID'),'image':v('ImageBase64'),'imageFormat':'png',
                      'title':v('Title'),'text':v('Body'),'summary':v('Summary'),'address':v('Address'),
                      'contactFirstName':v('ContactFirstName'),'contactLastName':v('ContactLastName'),
                      'contactCompany':v('ContactCompany'),'contactPhone':v('ContactPhone'),
                      'contactEmail':v('ContactEmail'),'contactNotes':v('ContactNotes'),
                      'created':v('Created'),'updated':v('Created')},'Record')
        save_record()
    b.empty('Incoming');b.route('detail')

def browse():
    storage();b.records();b.empty('CaptureLabels');b.set('CaptureNumber','0')
    with b.each(v('Files'),'BrowseFile'):
        b.parse(v('BrowseFile'),'BrowseRecord');title=b.get('title','BrowseRecord')
        b.set('CaptureNumber',b.a('math',WFInput=v('CaptureNumber'),WFMathOperand=1))
        clean=b.a('text.replace',WFInput=token(title),WFReplaceTextFind=r'[\r\n]+',WFReplaceTextReplace=' ',WFReplaceTextRegularExpression=True)
        b.append('CaptureLabels',b.txt('📸 ',clean,'\n#',v('CaptureNumber')))
    with b.iff(v('CaptureLabels')) as branch:
        chosen=b.choose(v('CaptureLabels'),'📚 All Captures')
        index=b.a('text.match',text=token(chosen),WFMatchTextPattern=r'(?<=#)\d+$',WFMatchTextCaseSensitive=True)
        b.set('SelectedFile',b.a('getitemfromlist',WFInput=v('Files'),WFItemSpecifier='Item At Index',WFItemIndex=token(index)))
        b.parse(v('SelectedFile'));b.route('detail')
        branch.otherwise();b.alert('No captures yet','Choose Photo or Take a Photo to add your first capture.');b.route('home')

def rename():
    b.ask('Capture title',v('Title'),dest='NewTitle')
    b.set('NewTitle',b.a('text.trimwhitespace',WFInput=token(v('NewTitle'))))
    with b.iff(v('NewTitle')):
        b.put('title',v('NewTitle'));b.now('Updated');b.put('updated',v('Updated'));save_record()

def edit_text():
    b.ask('Edit extracted text. Leave blank to keep the current text.',v('Body'),dest='NewBody',multiline=True)
    with b.iff(v('NewBody')):
        b.put('text',v('NewBody'));b.now('Updated');b.put('updated',v('Updated'));save_record()

def delete_capture():
    b.alert('🗑 Delete this capture?',token(v('Title'),'\n\nDelete this saved capture and any older recovery copy? Your original photo and items in other apps stay in place.'),True)
    b.empty('DeleteFiles');b.append('DeleteFiles',v('SelectedFile'))
    b.getfile('AppFolder',token('Recovery/',v('CaptureID'),'.json'),'OldRecovery')
    with b.iff(v('OldRecovery')):b.append('DeleteFiles',v('OldRecovery'))
    # The preceding alert is the confirmation. Immediate deletion avoids a
    # second iOS prompt that displays the raw JSON file contents.
    b.a('file.delete',WFInput=v('DeleteFiles'),WFDeleteImmediatelyDelete=True);b.route('browse')

def detail():
    load_fields()
    b.menu(token('📸 ',v('Title')),[
        ('⚡ Take Action',lambda:b.route('actions')),
        ('🖼 View Photo',lambda:(share_image(),b.a('previewdocument',WFInput=v('CaptureImage')))),
        ('📄 View Text',lambda:b.a('showresult',Text=token(v('Body')))),
        ('✏️ Rename Capture',rename),('📝 Edit Text',edit_text),
        ('🗑 Delete Capture',delete_capture),('🏠 Main Menu',lambda:b.route('home')),
    ])

def reminder():
    b.ask('Reminder title',v('Title'),dest='ReminderTitle')
    b.require(v('ReminderTitle'),'Title needed','No reminder was created.')
    b.menu('🔔 When?',[
        ('📅 Choose Day',lambda:b.ask('Choose the reminder day',kind='Date',dest='ReminderDate')),
        ('📥 No Due Date',lambda:b.empty('ReminderDate')),
    ])
    p={'WFCalendarItemTitle':token(v('ReminderTitle')),'WFCalendarItemNotes':token(v('Body')),'WFPriority':'None'}
    with b.iff(v('ReminderDate')) as branch:
        blank=b.a('nothing')
        b.a('addnewreminder',**p,WFImages=blank,WFAlertEnabled='Alert',WFAlertCondition='At Time',WFAlertCustomTime=token(v('ReminderDate')))
        branch.otherwise()
        blank=b.a('nothing')
        b.a('addnewreminder',**p,WFImages=blank,WFAlertEnabled='No Alert')

def event():
    b.ask('Choose the event day and time',kind='Date and Time',dest='EventDate')
    b.require(v('EventDate'),'Date needed','No event was created.')
    # A one-hour default removes the end-date prompt. The native editor lets
    # the user choose any writable calendar and adjust duration if desired.
    end=b.a('adjustdate',WFDate=token(v('EventDate')),WFInput=v('EventDate'),WFAdjustOperation='Add',
            WFDuration={'Value':{'Magnitude':'1','Unit':'hr'},'WFSerializationType':'WFQuantityFieldValue'},
            WFAdjustOffsetPicker={'Value':{'Operation':'Add','Unit':'Hour','Value':1},'WFSerializationType':'WFTimeOffsetValue'})
    b.a('addnewevent',WFCalendarItemTitle=token(v('Title')),WFCalendarItemStartDate=token(v('EventDate')),
        WFCalendarItemEndDate=token(end),WFCalendarItemAllDay=False,WFCalendarItemDates=True,
        WFCalendarItemNotes=token(v('Body')),WFAlertTime='15 minutes before',ShowWhenRun=True,
        WFCalendarItemCalendar=attachment({'Type':'Ask'}),WFCalendarDescriptor=attachment({'Type':'Ask'}))

def checklist():
    b.ask('One task per line',v('Body'),dest='ChecklistText',multiline=True)
    lines=b.a('text.match',text=token(v('ChecklistText')),WFMatchTextPattern=r'(?m)^\s*\S[^\r\n]*',WFMatchTextCaseSensitive=False)
    b.require(lines,'No tasks found','Enter one task per line.')
    b.choose(lines,'Select the tasks to create','ChosenTasks',multiple=True)
    b.require(v('ChosenTasks'),'No tasks selected','No reminders were created.')
    b.count(v('ChosenTasks'),'TaskCount')
    b.require_condition(v('TaskCount'),1,50,'Choose up to 50 tasks','No reminders were created.')
    with b.each(v('ChosenTasks'),'TaskLine'):
        title=b.a('text.trimwhitespace',WFInput=token(v('TaskLine')))
        blank=b.a('nothing')
        b.a('addnewreminder',WFCalendarItemTitle=token(title),WFCalendarItemNotes=token('From ',v('Title')),WFImages=blank,WFAlertEnabled='No Alert',WFPriority='None')

def save_note():
    share_image()
    descriptor={'AppIntentIdentifier':'CreateNoteLinkAction','BundleIdentifier':'com.apple.mobilenotes',
                'Name':'Notes','TeamIdentifier':'0000000000'}
    b.a('com.apple.mobilenotes.SharingExtension',AppIntentDescriptor=descriptor,
        WFCreateNoteInput=token(v('Title'),'\n\n',v('Summary'),'\n\n',v('Body'),'\n\n',v('CaptureImage')))

def maps():
    b.set('MapQuery',v('Address'))
    b.require(v('MapQuery'),'No address found','I could not find a clear address in this capture. Edit the capture text and try again.')
    encoded=b.a('urlencode',WFInput=token(v('MapQuery')),WFEncodeMode='Encode')
    b.a('openurl',WFInput=token(b.a('url',WFURLActionURL=token('https://maps.apple.com/?q=',encoded))))

def links():
    urls=b.a('detect.link',WFInput=token(v('Body')))
    b.require(urls,'No links found','Edit the capture text to correct the web address.')
    chosen=b.choose(urls,'Choose a website to open')
    valid=b.a('text.match',text=token(chosen),WFMatchTextPattern=r'(?i)^https?://[^\s]+$',WFMatchTextCaseSensitive=False)
    b.require(valid,'Web links only','Copy the text to use other link types.')
    b.a('openurl',WFInput=token(chosen))

def contact():
    full_name=b.txt(v('ContactFirstName'),' ',v('ContactLastName'))
    b.set('ContactName',b.a('text.trimwhitespace',WFInput=token(full_name)))
    b.require(v('ContactName'),'No contact found','I could not find a contact name in this capture.')
    details=b.txt(v('ContactNotes'),'\nPhone: ',v('ContactPhone'),'\nEmail: ',v('ContactEmail'))
    b.a('addnewcontact',WFContactFirstName=token(v('ContactFirstName')),WFContactLastName=token(v('ContactLastName')),
        WFContactCompany=token(v('ContactCompany')),WFContactNotes=token(details,'\n\n',v('Body')),ShowWhenRun=True)

def copy_text():
    b.ask('Text to copy',v('Body'),dest='CopyText',multiline=True)
    b.require(v('CopyText'),'Nothing to copy','Enter some text first.')
    b.a('setclipboard',WFInput=v('CopyText'),WFLocalOnly=True)

def pdf():
    share_image();b.empty('PDFInput');b.append('PDFInput',v('CaptureImage'));b.append('PDFInput',b.txt(v('Title'),'\n\n',v('Body')))
    output=b.a('makepdf',WFInput=v('PDFInput'),WFPDFIncludeMargin=True,WFPDFIncludedPages='All Pages')
    named=b.a('setitemname',WFInput=output,WFName='Screenshot-to-Action.pdf',WFDontIncludeFileExtension=False)
    b.a('share',WFInput=named)

def actions():
    b.menu(token('⚡ ',v('Title')),[
        ('🔔 Create Reminder',b.guarded(reminder)),('📅 Create Calendar Event',b.guarded(event)),('☑️ Create Checklist',b.guarded(checklist)),
        ('📝 Save to Notes',b.guarded(save_note)),('📋 Copy Text',b.guarded(copy_text)),('🗺 Find an Address',b.guarded(maps)),
        ('🔗 Open a Web Link',b.guarded(links)),('👤 Create Contact',b.guarded(contact)),
        ('🔊 Read Text Aloud',b.guarded(lambda:(b.require(v('Body'),'No text found','Use Edit Text to add some text.'),b.a('speaktext',WFText=token(v('Body')),WFSpeakTextWait=True)))),
        ('📑 Export PDF',b.guarded(pdf)),('↩️ Back to Capture',lambda:b.route('detail')),
    ])

def backup():
    b.records('BackupFiles');b.require(v('BackupFiles'),'Nothing to back up','Add a capture first.')
    now=b.a('date',WFDateActionMode='Current Date')
    stamp=b.a('format.date',WFDate=token(now),WFDateFormatStyle='Custom',WFDateFormat='yyyyMMdd-HHmmss-SSS')
    name=token('Screenshot-to-Action-',stamp,'.zip')
    archive=b.a('makezip',WFInput=v('BackupFiles'),WFArchiveFormat='zip',WFZIPName=token('Screenshot-to-Action-',stamp))
    b.savefile(archive,'Backups',name,'BackupFile',overwrite=False);b.a('share',WFInput=v('BackupFile'))

def validate_record(source):
    b.parse(source,'RestoreRecord')
    for key in ('format','schema','id','image','imageFormat','title'):b.get(key,'RestoreRecord','Restore'+key)
    fmt=b.a('text.match',text=token(v('Restoreformat')),WFMatchTextPattern='^'+re.escape(FORMAT)+'$',WFMatchTextCaseSensitive=True)
    b.require(fmt,'Unsupported backup','No captures were restored.')
    imgfmt=b.a('text.match',text=token(v('RestoreimageFormat')),WFMatchTextPattern='^png$',WFMatchTextCaseSensitive=True)
    b.require(imgfmt,'Unsupported image format','No captures were restored.')
    schema=b.a('text.match',text=token(v('Restoreschema')),WFMatchTextPattern=r'^[123]$',WFMatchTextCaseSensitive=True)
    b.require(schema,'Unsupported backup version','No captures were restored.')
    valid=b.a('text.match',text=token(v('Restoreid')),WFMatchTextPattern=ID_RE,WFMatchTextCaseSensitive=True)
    b.require(valid,'Invalid capture ID','No captures were restored.')
    b.require(v('Restoretitle'),'Missing capture title','No captures were restored.')
    keys=b.a('getvalueforkey',WFGetDictionaryValueType='All Keys',WFInput=v('RestoreRecord'))
    for key in ('text','created','updated'):
        exists=b.a('text.match',text=token(keys),WFMatchTextPattern=r'(?m)^'+key+'$',WFMatchTextCaseSensitive=True)
        b.require(exists,'Incomplete capture','No captures were restored. Required fields are missing.')
    # Legacy captures used a hash of image bytes; newer ones hash the Base64 text.
    # Make the dictionary value explicit text before hashing to avoid native
    # content-type coercion. Accept either hash only when it matches the saved ID.
    b.set('RestoreImageText',b.txt(v('Restoreimage')))
    decoded=b.a('base64encode',WFInput=v('RestoreImageText'),WFEncodeMode='Decode');b.set('DecodedImage',decoded)
    b.hash(v('RestoreImageText'),'RestoredHash')
    hashmatch=b.a('text.match',text=token(v('RestoredHash')),WFMatchTextPattern=token('^',v('Restoreid'),'$'),WFMatchTextCaseSensitive=True)
    b.set('HashMatch',hashmatch)
    with b.iff(v('HashMatch'),101):
        b.hash(v('DecodedImage'),'LegacyHash')
        legacy=b.a('text.match',text=token(v('LegacyHash')),WFMatchTextPattern=token('^',v('Restoreid'),'$'),WFMatchTextCaseSensitive=True)
        b.set('HashMatch',legacy)
    b.require(v('HashMatch'),'Backup image check failed','No captures were restored. A saved image does not match its capture ID.')
    b.require(b.a('detect.images',WFInput=v('DecodedImage')),'Unreadable backup image','No captures were restored.')

def restore():
    b.set('ValidationOK','yes');b.set('RestoreInput',b.a('file.select',WFPickingMode='Files',SelectMultiple=False))
    ext=b.a('properties.files',WFInput=v('RestoreInput'),WFContentItemPropertyName='File Extension')
    b.set('RestoreExtension',b.a('text.changecase',text=token(ext),WFCaseType='lowercase'))
    iszip=b.a('text.match',text=token(v('RestoreExtension')),WFMatchTextPattern='^zip$',WFMatchTextCaseSensitive=True)
    with b.iff(iszip) as branch:
        b.set('RestoreCandidates',b.a('unzip',WFArchive=v('RestoreInput')))
        branch.otherwise()
        isjson=b.a('text.match',text=token(v('RestoreExtension')),WFMatchTextPattern='^json$',WFMatchTextCaseSensitive=True)
        with b.iff(isjson) as inner:
            b.set('RestoreCandidates',v('RestoreInput'))
            inner.otherwise();b.alert('Choose ZIP or JSON','No captures were restored.');b.set('ValidationOK','no')
    ok=b.a('text.match',text=token(v('ValidationOK')),WFMatchTextPattern='^yes$',WFMatchTextCaseSensitive=True)
    b.require(ok,None,None)
    b.require(v('RestoreCandidates'),'Empty backup','No captures were restored.')
    b.empty('ValidatedFiles');b.empty('SeenIDs')
    with b.each(v('RestoreCandidates'),'RestoreFile'):
        ext=b.a('properties.files',WFInput=v('RestoreFile'),WFContentItemPropertyName='File Extension')
        extension=b.a('text.changecase',text=token(ext),WFCaseType='lowercase')
        isjson=b.a('text.match',text=token(extension),WFMatchTextPattern='^json$',WFMatchTextCaseSensitive=True)
        with b.iff(isjson):
            b.guarded(lambda:validate_record(v('RestoreFile')),on_failure=lambda:b.set('ValidationOK','no'))()
            stillok=b.a('text.match',text=token(v('ValidationOK')),WFMatchTextPattern='^yes$',WFMatchTextCaseSensitive=True)
            with b.iff(stillok):
                seen=b.a('text.match',text=token(v('SeenIDs')),WFMatchTextPattern=token('(?m)^',v('Restoreid'),'$'),WFMatchTextCaseSensitive=True)
                with b.iff(seen,101):b.append('ValidatedFiles',v('RestoreFile'));b.append('SeenIDs',v('Restoreid'))
    ok=b.a('text.match',text=token(v('ValidationOK')),WFMatchTextPattern='^yes$',WFMatchTextCaseSensitive=True)
    b.require(ok,None,None)
    b.require(v('ValidatedFiles'),'No captures found','Choose a Screenshot to Action backup.')
    b.set('ImportedCount','0');b.set('SkippedCount','0')
    with b.each(v('ValidatedFiles'),'ValidatedFile'):
        b.parse(v('ValidatedFile'),'IncomingRecord');b.get('id','IncomingRecord','IncomingID')
        b.getfile('Captures',token(v('IncomingID'),'.json'),'ExistingCapture')
        with b.iff(v('ExistingCapture')) as branch:
            b.set('SkippedCount',b.a('math',WFInput=v('SkippedCount'),WFMathOperand=1))
            branch.otherwise()
            b.savefile(v('ValidatedFile'),'Captures',token(v('IncomingID'),'.json'),overwrite=False)
            b.set('ImportedCount',b.a('math',WFInput=v('ImportedCount'),WFMathOperand=1))
    b.alert('Restore complete',token('Added: ',v('ImportedCount'),'\nAlready saved: ',v('SkippedCount')))

def backups():
    storage()
    with b.iff(v('Backups'),101):ensure_folder('Backups','AppFolder','Backups')
    b.menu('💾 Backup and Restore',[
        ('💾 Create Backup',b.guarded(backup)),('♻️ Restore Backup',b.guarded(restore)),('🏠 Main Menu',lambda:b.route('home')),
    ])

def about():
    b.menu(f'📸 Screenshot to Action\nv{VERSION} · Build {BUILD}\nCreated by 🐙 SurfKraken',[
        ('📖 How to Use',lambda:b.a('showresult',Text='Choose a photo or take a photo, then select Take Action. Apple Cloud analyzes the image and saves visible text, a summary, any clear address, and visible contact details. Rename or delete saved photos in All Captures.\n\nMaps opens the address found in the capture. If none is clear, edit the capture text and try again. Create Contact fills a contact sheet from visible details so you can review before saving.\n\nCalendar asks for one day and time, supplies a one-hour duration, prompts for your calendar, then opens Apple Calendar. Save to Notes creates a note using the capture title, summary, recognized text, and photo.\n\nImage analysis uses Apple Private Cloud Compute. It requires Apple Intelligence support and an internet connection. Apple may apply usage limits. Captures stay in iCloud Drive/Shortcuts/Screenshot to Action. Backups include images and extracted details.\n\nCreated by SurfKraken\nhttps://github.com/surfkraken\nA project repository backup is pending owner approval.')),
        ('🐙 SurfKraken on GitHub',lambda:b.a('openurl',WFInput=token(b.a('url',WFURLActionURL=GITHUB)))),
        ('🏠 Main Menu',lambda:b.route('home')),
    ])

def home():
    b.menu('📸 Screenshot to Action\nSee it. Sort it. Save it.',[
        ('🖼 Choose Photo',lambda:(b.set('Incoming',b.a('selectphoto',WFSelectMultiplePhotos=False)),b.route('capture'))),
        ('📷 Take a Photo',lambda:(b.set('Incoming',b.a('takephoto',WFCameraCaptureShowPreview=True,WFPhotoCount=1,WFCameraCaptureDevice='Back')),b.route('capture'))),
        ('📚 All Captures',lambda:b.route('browse')),
        ('💾 Backup and Restore',lambda:b.route('backups')),
        ('ℹ️ About and Help',lambda:b.route('about')),
        ('⏹ Quit',lambda:b.stop()),
    ])

def build():
    b.a('comment',WFCommentActionText=f'📸 Screenshot to Action · v{VERSION} · Build {BUILD}\nCreated by 🐙 SurfKraken\n{GITHUB}\n\nChoose or take a photo, save it, and choose an output. GitHub backup is pending owner approval.')
    b.set('Incoming',attachment({'Type':'ExtensionInput'}));b.empty('AppFolder');b.empty('Backups');b.route('home')
    with b.iff(v('Incoming')):b.route('capture')
    with b.countloop(100):
        b.set('Route',v('Screen'))
        for route,fn in [('home',home),('capture',b.guarded(capture)),('browse',browse),('detail',detail),('actions',actions),('backups',backups),('about',about)]:
            b.sections[route]=len(b.actions)
            with b.iff(v('Route'),4,route):fn()
    b.stop()
    result={'WFWorkflowName':NAME,'WFWorkflowClientVersion':'2700.0.4','WFWorkflowMinimumClientVersion':900,
        'WFWorkflowMinimumClientVersionString':'900','WFWorkflowHasOutputFallback':False,'WFWorkflowHasShortcutInputVariables':True,
        'WFWorkflowIcon':{'WFWorkflowIconGlyphNumber':59682,'WFWorkflowIconStartColor':463140863},
        'WFWorkflowTypes':['ActionExtension','NCWidget','WFWorkflowTypeShowInSearch'],
        'WFWorkflowInputContentItemClasses':['WFImageContentItem'],'WFWorkflowOutputContentItemClasses':[],
        'WFWorkflowImportQuestions':[],'WFQuickActionSurfaces':[],'WFWorkflowActions':b.actions}
    out=ROOT/'dist';out.mkdir(exist_ok=True)
    (out/(STEM+'.shortcut')).write_bytes(plistlib.dumps(result,fmt=plistlib.FMT_BINARY,sort_keys=False))
    (out/(STEM+'.xml')).write_bytes(plistlib.dumps(result,fmt=plistlib.FMT_XML,sort_keys=False))
    (out/'build-manifest.json').write_text(json.dumps({'name':NAME,'version':VERSION,'build':BUILD,'actions':len(b.actions),
        'sections':b.sections,'format':FORMAT,'schema':'3','legacy_restore_schemas':['1','2'],'github':GITHUB},indent=2))
    print(json.dumps({'actions':len(b.actions),'shortcut':str(out/(STEM+'.shortcut'))}))

if __name__=='__main__':build()
