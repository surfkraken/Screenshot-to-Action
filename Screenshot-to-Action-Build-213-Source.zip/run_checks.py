#!/usr/bin/env python3
"""Three focused validation rounds for the final serialized shortcut."""
import argparse,datetime,hashlib,io,json,pathlib,plistlib,subprocess,sys,time,unittest
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tests'))
from native_model import COVERED_ACTIONS,COVERED_MENU_CASES

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--reference-validator',type=pathlib.Path);args=parser.parse_args()
    artifact=ROOT/'dist/Screenshot-to-Action-v2.0-Build-213.shortcut'
    manifest=json.loads((ROOT/'dist/build-manifest.json').read_text());actions=plistlib.loads(artifact.read_bytes())['WFWorkflowActions']
    report={'artifact':artifact.name,'sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'bytes':artifact.stat().st_size,
            'generated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actions':len(actions),'previous_actions':2568,
            'action_reduction_percent':round(100*(1-len(actions)/2568),1),'apple_runtime_executed':False,
            'apple_import_verified':False,'github_published':False,'passes':[]}
    success=True;logs=[]
    for title,module in [('1. Native structure and input connections','test_structure'),('2. Simplified user workflows','test_workflows'),('3. Cancellation, legacy data, and backup failures','test_failures')]:
        stream=io.StringIO();start=time.monotonic();suite=unittest.defaultTestLoader.loadTestsFromName(module)
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
        row={'name':title,'test_methods':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'seconds':round(time.monotonic()-start,3),'passed':result.wasSuccessful()}
        report['passes'].append(row);success &= row['passed'];logs.append(title+'\n'+stream.getvalue());print(json.dumps(row))
    if args.reference_validator:
        proc=subprocess.run([sys.executable,str(args.reference_validator),str(artifact),'--target-macos','27','--target-platform','all'],capture_output=True,text=True)
        findings=[s[2:] for s in proc.stdout.splitlines() if s.startswith('- ')];reviewed=[];unexpected=[]
        for finding in findings:
            reason=None
            if finding in ('Second action must be the prompt Comment block','Second Comment missing required Shortcuts Playground prompt text') or finding.startswith('Insufficient Comment blocks:') or finding.startswith('Missing descriptive Comment immediately before control-flow start at index '):
                reason='Editorial comment/branding requirement of this third-party validator. Long instructional comment blocks were deliberately removed from the compact shortcut.'
            elif finding.startswith('Empty parameter at index ') and finding.endswith('fileLocation/relativeSubpath'):
                reason='Intentional empty relative path for the built-in Shortcuts root folder. No personal device bookmark is used.'
            if reason is None:unexpected.append(finding)
            reviewed.append({'finding':finding,'reviewed_reason':reason})
        accepted=proc.returncode==0 or (proc.returncode==1 and bool(findings) and not unexpected);success &= accepted
        report['reference_lint']={'raw_exit_code':proc.returncode,'raw_output':proc.stdout+proc.stderr,'reviewed_findings':reviewed,'unexpected_findings':unexpected,'review_passed':bool(accepted)}
    cases={i for i,a in enumerate(actions) if a['WFWorkflowActionIdentifier'].endswith('.choosefrommenu') and a['WFWorkflowActionParameters'].get('WFControlFlowMode')==1}
    missing=cases-COVERED_MENU_CASES;report['menu_branch_coverage']={'covered':len(cases & COVERED_MENU_CASES),'total':len(cases),'untested':[actions[i]['WFWorkflowActionParameters']['WFMenuItemTitle'] for i in sorted(missing)]}
    success &= not missing
    report['additional_randomized_roundtrips']=50
    report['automated_result']='PASS' if success else 'FAIL'
    report['meaningful_regressions']=[
        'Malformed attachment-only dictionary Value inputs are rejected. The pre-v2 test model incorrectly accepted them.',
        'Action and recoverable validation paths return to their prior menus; Quit remains last on the main menu.',
        'Capture creation performs one archive save. Every output action performs zero archive saves.',
        'Calendar uses one native Date picker with Date and Time granularity, an explicit calendar Ask token, and a one-hour computed end.',
        'Legacy schema-1, schema-2, and schema-3 records and ZIP backups restore without requiring retired activity, tags, or pending fields.',
        'Delete confirmation and cancellation preserve files; corrupt later ZIP records prevent all imports.',
    ]
    report['limitations']=[
        'Apple Shortcuts is unavailable in this environment. Import, native UI, picker appearance, calendar discovery, Apple Cloud model serialization/runtime, permissions, and app effects still require an iPhone run.',
        'The model runs the emitted plist with real JSON, SHA-256, PNG conversion, base64, and ZIP operations. Apple Use Model, Camera, Photos, Calendar, Reminders, Contacts, sharing, Maps, speech, and PDF rendering are test doubles.',
        'Elapsed time and the native date-only reminder behavior have not been measured on iPhone. The selected day is passed to the native alert field, which may apply a time.',
        'The original photo remains available if AI analysis or the first save fails. This compact version saves once after analysis and does not keep per-edit recovery snapshots or action checkpoints.',
        'A native service, permission, malformed JSON, or storage error can stop the run. Previously saved captures remain available. Interrupted native creation can leave a created item, so review its destination before manually retrying.',
        'Backups include current capture JSON files with their images. Version-1 Recovery files and older backup ZIPs are not included. Deleting a legacy capture also removes its matching old recovery copy after confirmation.',
        'Existing captures are skipped on restore. Avoid simultaneous edits to this archive from different devices.',
        'GitHub backup remains pending owner approval. About links to the verified SurfKraken profile until a project repository is selected or created.',
    ]
    (ROOT/'dist/automated-test-results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False));(ROOT/'dist/automated-test-log.txt').write_text('\n\n'.join(logs))
    rows='\n'.join('| '+r['name']+' | '+str(r['test_methods'])+' | '+('Passed' if r['passed'] else 'Failed')+' |' for r in report['passes'])
    md=f'''# Screenshot to Action v2.0, Build 213

Created by SurfKraken.

## Changes requested by Andy

The main menu contains Choose Photo, Take a Photo, All Captures, Backup and Restore, About and Help, and Quit last. It displays the tagline “See it. Sort it. Save it.” The earlier-action popup, tags, categories, inbox/archive statuses, action logging, and previous-version menus are removed. Rename and Delete remain on each capture. All ten output types remain.

The Notes action matches the identifier and App Intent descriptor from the user-provided iPhone export. The image is passed in the input alongside text; rendering both has not been confirmed on iPhone. Reminder asks for an optional day, without a time prompt. Completed outputs and handled validation errors return to the relevant menu.

Calendar asks once for the event day and time, supplies a one-hour duration, prompts for the user's calendar, then opens Apple's event editor. There is no separate end-date question. The duration remains editable in that editor.

Capture schemas 1, 2, and 3 are accepted by restore. Old pending fields are ignored. New schema-3 records contain the image, title, transcription, summary, address, detected contact fields, identifier, and timestamps.

## Fixes from Andy's device recording

Build 200 passed a Photos file directly to Get Dictionary from Input while listing captures. The phone showed “This action could not be run with the current user interface.” Build 202 first converts file content to text, then parses the JSON dictionary. It replaces the macOS-only image prompt with Apple Cloud Use Model and passes the photo directly for structured extraction. The map action uses the saved address instead of asking you to type it; contact details prefill Apple's review sheet. It also hashes the PNG's base64 text instead of passing the Photos image object to Generate Hash, which had produced an empty capture ID on-device. Deletion now uses the shortcut's explicit confirmation and suppresses the second native file-delete prompt that displayed the JSON record.

## Native input correction

Earlier builds assigned dictionary Value inputs as WFTextTokenAttachment objects. Apple's native text fields expect WFTextTokenString objects containing the reference. That is a concrete serialization defect consistent with the blank Value chips reported on the phone. The new audit checks field serialization types and the workflow model rejects the old encoding. Other dynamic text, URL, and date inputs receive the same audit.

Use Model receives the selected photo and returns a dictionary containing transcription, summary, a clear address, and any visible contact details. Map lookup uses that saved address directly, with no address-entry question. The contact sheet is prefilled from detected details and remains reviewable before saving. Cloud analysis requires Apple Intelligence support, connectivity, and available Apple usage allowance. The editor and model are simulated in the automated tests, not executed by Apple Shortcuts here.

## Automated results

Overall: {report['automated_result']}. This does not establish iPhone runtime compatibility.

| Round | Test methods | Result |
|---|---:|---|
{rows}

The failure round includes 50 additional randomized Unicode/JSON/ZIP restore round trips. Native menu branches exercised by the model: {report['menu_branch_coverage']['covered']} of {len(cases)}.

Artifact: `{artifact.name}`

SHA-256: `{report['sha256']}`

Native actions: {len(actions)}, down from 2,568 ({report['action_reduction_percent']}% fewer). Capture creation writes one archive file; output actions do not write the archive. Actual iPhone elapsed time was not measured.

## Reference lint

The separate external linter was not run for this build. The automated results are model and structural checks, not device execution.

## What still needs an iPhone

After signing and importing, verify the photo picker, camera, Apple Cloud extraction, one calendar date/time prompt, calendar chooser, event editor, other native output actions, delete confirmation, and backup/restore with actual Files/iCloud permissions. The tests here execute a model of the plist rather than Apple's runtime.

## Limits

'''+''.join('- '+x+'\n' for x in report['limitations'])
    (ROOT/'dist/Screenshot-to-Action-Test-Report.md').write_text(md)
    print(json.dumps({'result':report['automated_result'],'tests':sum(r['test_methods'] for r in report['passes']),'menu_choices':report['menu_branch_coverage'],'actions':len(actions),'sha256':report['sha256']}))
    return 0 if success else 1

if __name__=='__main__':raise SystemExit(main())
